
MATRIX MTTY(1,1)$$

%File: Cart_cseo.r$

off echo$


% Begin Matrix MTTY$

mtty(1,1) := mttx2$

% End Matrix MTTY$

END;$

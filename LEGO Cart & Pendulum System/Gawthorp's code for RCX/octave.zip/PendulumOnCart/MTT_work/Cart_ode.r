%File: Cart_ode.r$
off echo$
% Begin Matrix MTTdX$
mttdx(1,1) := (g*m*mttu1 - mttx1*r)/m$
mttdx(2,1) := mttx1/m$
% End Matrix MTTdX$
in "Cart_odeo.r";$
END;$

matrix MTTTF(1,1)$
$
MTTTF(1,1) := (g*(c_p*r_p*s + 1))/(s*(c_p*m_p*r*s**2 + c_p*m_p*r_p*s**2 + c_p*m_p*s**3 + c_p*r*r_p*s + c_p*r_p*s**2 + m_p*s + r + s))$
;END;$

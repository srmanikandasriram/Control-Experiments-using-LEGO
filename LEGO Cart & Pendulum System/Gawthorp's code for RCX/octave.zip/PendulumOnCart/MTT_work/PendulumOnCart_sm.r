MATRIX MTTA(4,4)$
$
MATRIX MTTB(4,1)$
$
MATRIX MTTC(1,4)$
$
MATRIX MTTD(1,1)$
$
%File: PendulumOnCart_ode.r$
% New constants$
MTTNx := 4;$
MTTNy := 1;$
off echo$
% Begin Matrix MTTA$
mtta(1,1) := - (r + r_p)$
mtta(1,2) := ( - 1)/c_p$
mtta(1,3) := r_p/m_p$
mtta(1,4) := 0$
mtta(2,1) := 1$
mtta(2,2) := 0$
mtta(2,3) := ( - 1)/m_p$
mtta(2,4) := 0$
mtta(3,1) := r_p$
mtta(3,2) := 1/c_p$
mtta(3,3) := ( - r_p)/m_p$
mtta(3,4) := 0$
mtta(4,1) := 0$
mtta(4,2) := 0$
mtta(4,3) := 1/m_p$
mtta(4,4) := 0$
% End Matrix MTTA$
% Begin Matrix MTTB$
mttb(1,1) := g$
mttb(2,1) := 0$
mttb(3,1) := 0$
mttb(4,1) := 0$
% End Matrix MTTB$
% Begin Matrix MTTC$
mttc(1,1) := 0$
mttc(1,2) := 0$
mttc(1,3) := 0$
mttc(1,4) := 1$
% End Matrix MTTC$
% Begin Matrix MTTD$
mttd(1,1) := 0$
% End Matrix MTTD$
END;$

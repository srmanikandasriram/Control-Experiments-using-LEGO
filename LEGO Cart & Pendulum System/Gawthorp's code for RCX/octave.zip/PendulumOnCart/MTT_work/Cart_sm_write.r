
off echo$
load gentran$
write "% Begin Matrix MTTA"$
write
  MTTA(1,1) := MTTA(1,1) $
write
  MTTA(1,2) := MTTA(1,2) $
write
  MTTA(2,1) := MTTA(2,1) $
write
  MTTA(2,2) := MTTA(2,2) $
write "% End Matrix MTTA"$
write "% Begin Matrix MTTB"$
write
  MTTB(1,1) := MTTB(1,1) $
write
  MTTB(2,1) := MTTB(2,1) $
write "% End Matrix MTTB"$
write "% Begin Matrix MTTC"$
write
  MTTC(1,1) := MTTC(1,1) $
write
  MTTC(1,2) := MTTC(1,2) $
write "% End Matrix MTTC"$
write "% Begin Matrix MTTD"$
write
  MTTD(1,1) := MTTD(1,1) $
write "% End Matrix MTTD"$
;END;

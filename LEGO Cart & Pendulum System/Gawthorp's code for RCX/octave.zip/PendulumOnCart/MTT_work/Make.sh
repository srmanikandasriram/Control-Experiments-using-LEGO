#! /bin/sh

./MakeController.sh Cart 0.05 0.01
./MakeController.sh PendulumOnCart 0.05 0.05


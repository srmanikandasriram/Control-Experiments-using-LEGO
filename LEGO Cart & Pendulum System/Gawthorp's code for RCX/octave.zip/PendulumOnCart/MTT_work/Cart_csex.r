
%File:Cart_csex.r1$

MATRIX MTTEdx(2,1)$$

%File: Cart_cse.r$

off echo$


% Begin Matrix MTTEdX$

mttedx(1,1) := (g*m*mttu1 - mttx1*r)/m$

mttedx(2,1) := mttx1/m$

% End Matrix MTTEdX$

END;$

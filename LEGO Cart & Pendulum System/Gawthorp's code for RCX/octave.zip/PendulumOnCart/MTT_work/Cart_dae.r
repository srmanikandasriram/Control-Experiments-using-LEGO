MTTNu := 1$
MTTNx := 2$
MTTNz := 0$
MTTNy := 1$
MTTNyz := 0$
clear MTTdX;$
MATRIX MTTdX(2,1);$
MTTdX(1,1) := (g*m*mttu1 - mttx1*r)/m;$
MTTdX(2,1) := mttx1/m;$
clear MTTy;$
MATRIX MTTy(1,1);$
MTTy(1,1) := mttx2;$
END;$
% New constants$
MTTNx := 2;$
MTTNy := 1;$
matrix MTTE(2,2);$
MTTE(1,1) := 1$
MTTE(2,2) := 1$
matrix MTTA(2,2);$
MTTA(1,1) := ( - r)/m$
MTTA(2,1) := 1/m$
matrix MTTB(2,1);$
MTTB(1,1) := g$
matrix MTTC(1,2);$
MTTC(1,2) := 1$
matrix MTTD(1,1);$
END;$

/* File Cart_con.c */
/* Created by MakeController.sh at Tue Apr  6 10:03:18 BST 2004 */
/* Using control weight lambda=0.05 and observer weight sigma=0.01 */
double controller(double y, double u_out, double w, double x[N_state])
{
  double u,e,xdot;
  /* Error equations */
  e = -y + x[1];
  /* State estimator */
  xdot = - 2.30968*x[0] + 1.91551*u_out - 1.68575*e;
  x[0] = x[0] + xdot*DT;
  xdot = + x[0] - 10.1672*e;
  x[1] = x[1] + xdot*DT;
  /* Control signal */
  u = 4.47214*w - 1.26875*x[0] - 4.47214*x[1];
  return u;
}

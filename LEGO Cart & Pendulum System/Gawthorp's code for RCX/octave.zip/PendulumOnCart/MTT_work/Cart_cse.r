%$
MATRIX MTTEdx(2,1)$
$
MATRIX MTTE(2,2)$
$
%File: Cart_cse.r$
off echo$
% Begin Matrix MTTEdX$
mttedx(1,1) := (g*m*mttu1 - mttx1*r)/m$
mttedx(2,1) := mttx1/m$
% End Matrix MTTEdX$
% Begin Matrix MTTE$
mtte(1,1) := 1$
mtte(2,2) := 1$
% End Matrix MTTE$
in "Cart_cseo.r";$
END;$
;END;$

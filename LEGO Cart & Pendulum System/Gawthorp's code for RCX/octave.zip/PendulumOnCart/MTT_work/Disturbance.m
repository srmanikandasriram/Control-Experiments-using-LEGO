## Plot figures for disturbance

grid("off");
title("");
ylabel("");
xlabel("Time (sec)");

load -force Cart_dist.dat
figure(1)
plot(t,y ,t,u);
axis([0 5 -0.3 0.3]);
figfig("Cart_dist","eps",0,1);

load -force PendulumOnCart_dist.dat
figure(2)
axis([0 5 -0.6 0.8]);
plot(t,y ,t,u);
figfig("PendulumOnCart_dist","eps",0,1);




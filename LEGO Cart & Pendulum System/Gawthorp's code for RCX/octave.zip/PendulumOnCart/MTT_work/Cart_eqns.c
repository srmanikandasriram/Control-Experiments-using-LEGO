  /* Error equations */
  e = -y + x[1];
  /* State estimator */
  xdot = - 2.30968*x[0] + 1.91551*u_out - 1.68575*e;
  x[0] = x[0] + xdot*DT;
  xdot = + x[0] - 10.1672*e;
  x[1] = x[1] + xdot*DT;
  /* Control signal */
  u = 4.47214*w - 1.26875*x[0] - 4.47214*x[1];

MTTNx := 2;
MTTNz := 0;
MTTNu := 1;
MTTNy := 1;
MTTNyz := 0;
MTTNui := 0;
MTTNuc := 0;
% Declare reduce matrices
matrix MTTx(2,1);
matrix MTTdx(2,1);
matrix MTTu(1,1);
matrix MTTdu(1,1);
matrix MTTy(1,1);
matrix MTTI(2,2);
MTTI(1,1) := 1;
MTTI(2,2) := 1;
matrix MTTIm(1,1);
MTTIM(1,1) := 1;
% Set the y, yz, u and x matrices
MTTy(1,1) := MTTy1;
MTTu(1,1) := MTTu1;
MTTdu(1,1) := MTTdu1;
MTTx(1,1) := MTTx1;
MTTx(2,1) := MTTx2;
END;

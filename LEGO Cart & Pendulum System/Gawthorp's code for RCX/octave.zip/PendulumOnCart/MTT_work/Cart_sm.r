MATRIX MTTA(2,2)$
$
MATRIX MTTB(2,1)$
$
MATRIX MTTC(1,2)$
$
MATRIX MTTD(1,1)$
$
%File: Cart_ode.r$
% New constants$
MTTNx := 2;$
MTTNy := 1;$
off echo$
% Begin Matrix MTTA$
mtta(1,1) := ( - r)/m$
mtta(1,2) := 0$
mtta(2,1) := 1/m$
mtta(2,2) := 0$
% End Matrix MTTA$
% Begin Matrix MTTB$
mttb(1,1) := g$
mttb(2,1) := 0$
% End Matrix MTTB$
% Begin Matrix MTTC$
mttc(1,1) := 0$
mttc(1,2) := 1$
% End Matrix MTTC$
% Begin Matrix MTTD$
mttd(1,1) := 0$
% End Matrix MTTD$
END;$

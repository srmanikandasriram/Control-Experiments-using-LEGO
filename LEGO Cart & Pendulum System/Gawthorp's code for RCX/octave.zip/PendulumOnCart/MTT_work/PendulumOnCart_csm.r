% New constants$
MTTNx := 4;$
MTTNy := 1;$
matrix MTTE(4,4);$
MTTE(1,1) := 1$
MTTE(2,2) := 1$
MTTE(3,3) := 1$
MTTE(4,4) := 1$
matrix MTTA(4,4);$
MTTA(1,1) := - (r + r_p)$
MTTA(1,2) := ( - 1)/c_p$
MTTA(1,3) := r_p/m_p$
MTTA(2,1) := 1$
MTTA(2,3) := ( - 1)/m_p$
MTTA(3,1) := r_p$
MTTA(3,2) := 1/c_p$
MTTA(3,3) := ( - r_p)/m_p$
MTTA(4,3) := 1/m_p$
matrix MTTB(4,1);$
MTTB(1,1) := g$
matrix MTTC(1,4);$
MTTC(1,4) := 1$
matrix MTTD(1,1);$
END;$

#! /bin/sh
## Makes controller code.

name=$1
lambda=$2
sigma=$3
filename=${name}_con.c

date=`date`
octave -q <<EOF
  MakeController("${name}", ${lambda}, ${sigma});
EOF

cat <<EOF > ${filename}
/* File ${filename} */
/* Created by MakeController.sh at ${date} */
/* Using control weight lambda=${lambda} and observer weight sigma=${sigma} */
  
double controller(double y, double w, double x[N_state])
{
  double u,e,xdot;

EOF

cat < $1_eqns.c >> ${filename}

cat <<EOF >> ${filename}
  return u;
}
EOF
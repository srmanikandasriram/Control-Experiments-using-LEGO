
off echo$
load gentran$
write "% Begin Matrix MTTEdX"$
write
  MTTEdX(1,1) := MTTEdX(1,1) $
write
  MTTEdX(2,1) := MTTEdX(2,1) $
write "% End Matrix MTTEdX"$
write "% Begin Matrix MTTE"$
write
  MTTE(1,1) := MTTE(1,1) $
write
  MTTE(2,2) := MTTE(2,2) $
write "% End Matrix MTTE"$
;END;

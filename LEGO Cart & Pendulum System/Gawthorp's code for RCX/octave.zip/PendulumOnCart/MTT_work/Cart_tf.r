matrix MTTTF(1,1)$
$
MTTTF(1,1) := g/(s*(m*s + r))$
;END;$

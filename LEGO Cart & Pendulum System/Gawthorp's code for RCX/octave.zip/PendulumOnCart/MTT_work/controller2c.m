function eqns = controller2c (A,B,C,D,K,L,g_ss)

  ## usage:  eqns = controller2c (A,B,C,D,K,L,g_ss)
  ##
  ## Copyright (C) 2003,2004 by Peter J. Gawthrop
  ## $Id: controller2c.m,v 1.1 2004/03/08 16:54:29 peterg Exp $


  [n_x,n_u,n_y] = abcddim(A,B,C,D);

  eqns = "";			# Initialise string

  ## Error
  eqns = sprintf("%s/* Error equations */\n",eqns);
  for i = 1:n_y
    eqn = sprintf("e[%i]\t= -y[%i]\n", i-1, i-1);
    eqn = matrix2c(C,i,"x",eqn);
  endfor
  eqns = sprintf("%s%s;\n", eqns, eqn);


  ## Observer
  eqns = sprintf("%s\n/* State estimator */\n", eqns);
  for i = 1:n_x
    eqn = sprintf("xdot\t= 0.0\n");

    ## A matrix
    eqn = matrix2c(A,i,"x",eqn);

    ## B Matrix;
    eqn = matrix2c(B,i,"u",eqn);

    ## L Matrix;
    eqn = matrix2c(-L,i,"e",eqn);

    eqn = sprintf("%s\t;\nx[%i]\t= x[%i] + xdot*DT;\n\n", eqn,i-1,i-1);
    eqns = sprintf("%s%s", eqns, eqn);
  endfor

  ## Controller
  eqns = sprintf("%s\n/* Control signal */\n", eqns);
  for i=1:n_u
    eqn = sprintf("u[%i]\t= %g*w\n",i-1,1/g_ss);
    eqn = matrix2c(-K,i,"x",eqn);
    eqns = sprintf("%s%s;\n", eqns, eqn);
  endfor

  ## Replace arrays by scalars
  if (n_u==1)
    eqns = strrep (eqns,"u[0]","u");
  endif
  
  if (n_y==1)
    eqns = strrep (eqns,"y[0]","y");
    eqns = strrep (eqns,"e[0]","e");
  endif
  
endfunction
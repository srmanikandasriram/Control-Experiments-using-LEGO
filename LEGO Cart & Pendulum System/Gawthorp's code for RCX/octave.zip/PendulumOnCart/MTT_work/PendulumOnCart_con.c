/* File PendulumOnCart_con.c */
/* Created by MakeController.sh at Tue Apr  6 09:57:54 BST 2004 */
/* Using control weight lambda=0.05 and observer weight sigma=0.05 */
double controller(double y, double u_out, double w, double x[N_state])
{
  double u,e,xdot;
  /* Error equations */
  e = -y + x[3];
  /* State estimator */
  xdot = - 2.30968*x[0] - 2.58158*x[1] + 1.91551*u_out + 0.909516*e;
  x[0] = x[0] + xdot*DT;
  xdot = + x[0] - 10*x[2] + 4.68795*e;
  x[1] = x[1] + xdot*DT;
  xdot = + 2.58158*x[1] - 4.16972*e;
  x[2] = x[2] + xdot*DT;
  xdot = + 10*x[2] - 10.1683*e;
  x[3] = x[3] + xdot*DT;
  /* Control signal */
  u[0] = 4.47214*w - 1.89038*x[0] - 7.78873*x[1] + 0.48409*x[2] - 4.47214*x[3];
  return u;
}

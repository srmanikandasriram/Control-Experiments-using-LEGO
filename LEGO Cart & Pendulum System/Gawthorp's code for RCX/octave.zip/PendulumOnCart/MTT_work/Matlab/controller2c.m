function eqns = controller2c (A,B,C,D,K,L,g_ss)
  %% usage:  eqns = controller2c (A,B,C,D,K,L,g_ss)
  %%
  %% Copyright (C) 2003,2004 by Peter J. Gawthrop
  %% $Id: controller2c.m,v 1.6 2004/04/06 08:56:04 peterg Exp peterg $
  [n_x,n_u,n_y] = abcddim(A,B,C,D); % Dimensions
  eqns = '';			% Initialise string

  %% Error equations
  eqns = sprintf('%s  /* Error equations */\n',eqns);
  for i = 1:n_y
    eqn = sprintf('  e[%i] = -y[%i]', i-1, i-1);
    eqn = matrix2c(C,i,'x',eqn); % C matrix
  end%for
  eqns = sprintf('%s%s;\n', eqns, eqn);

  %% Observer equations
  eqns = sprintf('%s  /* State estimator */\n', eqns);
  for i = 1:n_x
    eqn = sprintf('  xdot =');
    eqn = matrix2c(A,i,'x',eqn); % A matrix
    eqn = matrix2c(B,i,'u_out',eqn); % B matric
    eqn = matrix2c(-L,i,'e',eqn); % L matrix
    eqn = sprintf('%s;\n  x[%i] = x[%i] + xdot*DT;\n', eqn,i-1,i-1);
    eqns = sprintf('%s%s', eqns, eqn);
  end%for

  %% Controller equations
  eqns = sprintf('%s  /* Control signal */\n', eqns);
  for i=1:n_u
    eqn = sprintf('  u[%i] = %g*w',i-1,1/g_ss);
    eqn = matrix2c(-K,i,'x',eqn); % K matrix
    eqns = sprintf('%s%s;\n', eqns, eqn);
  end%for

  %% Replace arrays by scalars
  if (n_u==1)
    eqns = strrep (eqns,'u_out[0]','u_out');
  end%if
  if (n_y==1)
    eqns = strrep (eqns,'y[0]','y');
    eqns = strrep (eqns,'e[0]','e');
  end%if
%endfunction
#! /bin/sh
## Turns code into LaTeX

texifyc++ <lego.c      >lego.c.tex
texifyc++ <lego.h      >lego.h.tex
texifyc++ <actuators.c >actuators.c.tex
texifyc++ <sensors.c   >sensors.c.tex



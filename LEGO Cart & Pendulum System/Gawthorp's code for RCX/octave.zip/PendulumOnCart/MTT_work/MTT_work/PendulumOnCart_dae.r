MTTNu := 1$
MTTNx := 4$
MTTNz := 0$
MTTNy := 1$
MTTNyz := 0$
clear MTTdX;$
MATRIX MTTdX(4,1);$
MTTdX(1,1) := (m_p*mttx2 - mttx3)/m_p;$
MTTdX(2,1) := (c_p*g*m_p*mttu1 - c_p*m_p*mttx2*r - c_p*m_p*mttx2*r_p + c_p*mttx3*r_p - m_p*mttx1)/(c_p*m_p);$
MTTdX(3,1) := (c_p*m_p*mttx2*r_p - c_p*mttx3*r_p + m_p*mttx1)/(c_p*m_p);$
MTTdX(4,1) := mttx3/m_p;$
clear MTTy;$
MATRIX MTTy(1,1);$
MTTy(1,1) := mttx4;$
END;$

off echo$
load gentran$
write "% Begin Matrix MTTY"$
write
  MTTY(1,1) := MTTY(1,1) $
write "% End Matrix MTTY"$
;END;

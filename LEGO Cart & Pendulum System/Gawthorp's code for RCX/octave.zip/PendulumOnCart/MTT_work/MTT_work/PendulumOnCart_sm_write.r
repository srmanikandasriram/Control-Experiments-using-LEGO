
off echo$
load gentran$
write "% Begin Matrix MTTA"$
write
  MTTA(1,1) := MTTA(1,1) $
write
  MTTA(1,2) := MTTA(1,2) $
write
  MTTA(1,3) := MTTA(1,3) $
write
  MTTA(1,4) := MTTA(1,4) $
write
  MTTA(2,1) := MTTA(2,1) $
write
  MTTA(2,2) := MTTA(2,2) $
write
  MTTA(2,3) := MTTA(2,3) $
write
  MTTA(2,4) := MTTA(2,4) $
write
  MTTA(3,1) := MTTA(3,1) $
write
  MTTA(3,2) := MTTA(3,2) $
write
  MTTA(3,3) := MTTA(3,3) $
write
  MTTA(3,4) := MTTA(3,4) $
write
  MTTA(4,1) := MTTA(4,1) $
write
  MTTA(4,2) := MTTA(4,2) $
write
  MTTA(4,3) := MTTA(4,3) $
write
  MTTA(4,4) := MTTA(4,4) $
write "% End Matrix MTTA"$
write "% Begin Matrix MTTB"$
write
  MTTB(1,1) := MTTB(1,1) $
write
  MTTB(2,1) := MTTB(2,1) $
write
  MTTB(3,1) := MTTB(3,1) $
write
  MTTB(4,1) := MTTB(4,1) $
write "% End Matrix MTTB"$
write "% Begin Matrix MTTC"$
write
  MTTC(1,1) := MTTC(1,1) $
write
  MTTC(1,2) := MTTC(1,2) $
write
  MTTC(1,3) := MTTC(1,3) $
write
  MTTC(1,4) := MTTC(1,4) $
write "% End Matrix MTTC"$
write "% Begin Matrix MTTD"$
write
  MTTD(1,1) := MTTD(1,1) $
write "% End Matrix MTTD"$
;END;

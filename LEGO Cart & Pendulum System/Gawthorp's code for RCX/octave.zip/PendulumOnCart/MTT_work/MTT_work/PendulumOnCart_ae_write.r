
off echo$
load gentran$
write "% Begin Matrix MTTYz"$
write "% End Matrix MTTYz"$
;END;

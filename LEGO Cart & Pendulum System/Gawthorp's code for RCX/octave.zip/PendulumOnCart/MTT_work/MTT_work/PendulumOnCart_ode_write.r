
off echo$
load gentran$
write "% Begin Matrix MTTdX"$
write
  MTTdX(1,1) := MTTdX(1,1) $
write
  MTTdX(2,1) := MTTdX(2,1) $
write
  MTTdX(3,1) := MTTdX(3,1) $
write
  MTTdX(4,1) := MTTdX(4,1) $
write "% End Matrix MTTdX"$
;END;

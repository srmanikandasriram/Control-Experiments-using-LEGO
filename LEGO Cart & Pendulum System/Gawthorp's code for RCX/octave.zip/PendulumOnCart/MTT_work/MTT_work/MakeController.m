function MakeController (Name)

  ## usage:  MakeController (Name)
  ##
  ## 

  if nargin<1
    error("usage:  MakeController (Name)");
  endif
  
  ## Makes the controller code
  sys = mtt2sys(Name); # System in octave form
  [n_x,n_z,n_u,n_y] = sysdimensions(sys);	# Sizes
  [A,B,C,D] = sys2ss(sys)

  ## LQ design
  ## Controller
  lambda = 0.1;			# Control weighting
  lambda_x = C'*C;
  lambda_u = lambda*eye(n_u);
  [K,P,c_poles] = lqr(A,B,lambda_x,lambda_u)

  sigma = 0.1;			# Measurement noise
  sigma_x = eye(n_u);
  sigma_y = sigma*eye(n_y);
  [L,Q,o_poles] = lqe(A,eye(n_x),C,sigma_x,sigma_y);

  ## Closed-loop system
  g_ss = -C*((A-B*K)\B);
  c_sys = ss2sys(A-B*K, B/g_ss, [C;-K], [D;1/g_ss]);
  step(c_sys);


  ## Create equations
  eqns = c_controller (A,B,C,D,K,L,g_ss);

  ## Write to file
  filename = sprintf("%s_eqns.c",Name);
  fid = fopen(filename,"w");
  fprintf(fid,"%s", eqns);
  fclose(fid);

endfunction

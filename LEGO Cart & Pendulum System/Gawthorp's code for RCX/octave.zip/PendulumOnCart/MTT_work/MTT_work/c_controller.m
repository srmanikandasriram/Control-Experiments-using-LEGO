function eqns = c_controller (A,B,C,D,K,L,g_ss)

  ## usage:  eqns = c_controller (A,B,C,D,K,L,g_ss)
  ##
  ## 


  [n_x,n_u,n_y] = abcddim(A,B,C,D);

  eqns = "";

  ## Error
  eqns = sprintf("%s/* Error equations */\n",eqns);
  for i = 1:n_y
    eqn = sprintf("e[%i]\t= -y[%i]\n", i-1, i-1);
    for j = 1:n_x
      c_ij = C(i,j);
      if (c_ij>0)
	eqn = sprintf("%s\t+ %g*x[%i]\n", eqn, c_ij, j-1);
      elseif (c_ij<0)
	eqn = sprintf("%s\t- %g*x[%i]\n", eqn, -c_ij, j-1);
      endif
    endfor
  endfor
  eqns = sprintf("%s%s;\n", eqns, eqn);


  ## Observer
  eqns = sprintf("%s\n/* State estimator */\n", eqns);
  for i = 1:n_x
    eqn = sprintf("xdot\t= 0.0\n");

    ## A matrix
    for j = 1:n_x
      a_ij = A(i,j);
      if (a_ij>0)
	eqn = sprintf("%s\t+ %g*x[%i]\n", eqn, a_ij, j-1);
      elseif (a_ij<0)
	eqn = sprintf("%s\t- %g*x[%i]\n", eqn, -a_ij, j-1);
      endif
    endfor

    ## B Matrix;
    for j = 1:n_u
      b_ij = B(i,j);
      if (b_ij>0)
	eqn = sprintf("%s\t+ %g*u[%i]\n", eqn, b_ij, j-1);
      elseif (b_ij<0)
	eqn = sprintf("%s\t- %g*u[%i]\n", eqn, -b_ij, j-1);
      endif
    endfor

    ## L Matrix;
    for j = 1:n_y
      l_ij = L(i,j);
      if (l_ij>0)
	eqn = sprintf("%s\t+ %g*e[%i]\n", eqn, l_ij, j-1);
      elseif (l_ij<0)
	eqn = sprintf("%s\t- %g*e[%i]\n", eqn, -l_ij, j-1);
      endif
    endfor

    eqn = sprintf("%s\t;\nx[%i]\t= x[%i] + xdot*DT;\n\n", eqn,i-1,i-1);
    eqns = sprintf("%s%s", eqns, eqn);
  endfor

  ## Controller
  eqns = sprintf("%s\n/* Control signal */\n", eqns);
  for i=1:n_u
    eqn = sprintf("u[%i]\t= %g*w\n",i-1,1/g_ss);
    for j=1:n_x
      k_ij = K(i,j);
      if (k_ij>0)
	eqn = sprintf("%s\t- %g*x[%i]\n", eqn, k_ij, j-1);
      elseif (k_ij<0)
	eqn = sprintf("%s\t+ %g*x[%i]\n", eqn, -k_ij, j-1);
      endif
    endfor
    eqns = sprintf("%s%s;\n", eqns, eqn);
  endfor

  ## Replace arrays by scalars
  if (n_u==1)
    eqns = strrep (eqns,"u[0]","u");
  endif
  
  if (n_y==1)
    eqns = strrep (eqns,"y[0]","y");
    eqns = strrep (eqns,"e[0]","e");
  endif
  
endfunction
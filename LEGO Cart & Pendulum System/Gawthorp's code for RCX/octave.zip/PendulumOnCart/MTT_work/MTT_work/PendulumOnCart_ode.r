%File: PendulumOnCart_ode.r$
off echo$
% Begin Matrix MTTdX$
mttdx(1,1) := (m_p*mttx2 - mttx3)/m_p$
mttdx(2,1) := (c_p*g*m_p*mttu1 - c_p*m_p*mttx2*r - c_p*m_p*mttx2*r_p + c_p*mttx3*r_p - m_p*mttx1)/(c_p*m_p)$
mttdx(3,1) := (c_p*m_p*mttx2*r_p - c_p*mttx3*r_p + m_p*mttx1)/(c_p*m_p)$
mttdx(4,1) := mttx3/m_p$
% End Matrix MTTdX$
in "PendulumOnCart_odeo.r";$
END;$

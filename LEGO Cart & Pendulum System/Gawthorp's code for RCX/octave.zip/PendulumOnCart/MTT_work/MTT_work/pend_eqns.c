/* Error equations */
e	= -y
	+ 1*x[3]
;

/* State estimator */
xdot	= 0.0
	+ 1*x[1]
	- 100*x[2]
	- 21.1556*e
	;
x[0]	= x[0] + xdot*DT;

xdot	= 0.0
	- 0.258158*x[0]
	- 1.28303*x[1]
	+ 1.27962*u
	- 0.114552*e
	;
x[1]	= x[1] + xdot*DT;

xdot	= 0.0
	+ 0.258158*x[0]
	+ 2.97488*e
	;
x[2]	= x[2] + xdot*DT;

xdot	= 0.0
	+ 100*x[2]
	+ 24.5963*e
	;
x[3]	= x[3] + xdot*DT;


/* Control signal */
u	= 3.16228*w
	- 5.46669*x[0]
	- 2.08757*x[1]
	+ 38.1631*x[2]
	- 3.16228*x[3]
;

in "PendulumOnCart_def.r"$
clear MTTdX;$
MATRIX MTTdX(4,1);$
MTTdX(1,1) := - lin(i,flow,m_p,flow,1,mttx3,state,1) + lin(i,flow,1,flow,1,mttx2,state,1);$
MTTdX(2,1) := lin(ae,g,effort,2,mttu1,effort,1) - lin(c,effort,c_p,effort,1,mttx1,state,1) - lin(r,flow,r,effort,1,lin(i,flow,1,flow,1,mttx2,state,1),flow,1) - lin(r,flow,r_p,effort,1, - lin(i,flow,m_p,flow,1,mttx3,state,1) + lin(i,flow,1,flow,1,mttx2,state,1),flow,1);$
MTTdX(3,1) := lin(c,effort,c_p,effort,1,mttx1,state,1) + lin(r,flow,r_p,effort,1, - lin(i,flow,m_p,flow,1,mttx3,state,1) + lin(i,flow,1,flow,1,mttx2,state,1),flow,1);$
MTTdX(4,1) := lin(i,flow,m_p,flow,1,mttx3,state,1);$
clear MTTy;$
MATRIX MTTy(1,1);$
MTTy(1,1) := mttx4;$
END;$
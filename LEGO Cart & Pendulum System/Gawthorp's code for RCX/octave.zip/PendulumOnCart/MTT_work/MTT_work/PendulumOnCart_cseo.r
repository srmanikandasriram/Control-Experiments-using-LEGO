
MATRIX MTTY(1,1)$$

%File: PendulumOnCart_cseo.r$

off echo$


% Begin Matrix MTTY$

mtty(1,1) := mttx4$

% End Matrix MTTY$

END;$

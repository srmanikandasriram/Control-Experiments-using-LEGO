/* 	$Id: pend_con.c,v 1.1 2003/07/23 12:22:11 peterg Exp peterg $	 */
/* State-space controller for the double pendulum system */

double controller(double y, double u_old, double w, double x[N_state])
{
  double u,e,xdot;

  u = u_old;			/* u from last time */

#include "pend_eqns.c"

  return u;
}

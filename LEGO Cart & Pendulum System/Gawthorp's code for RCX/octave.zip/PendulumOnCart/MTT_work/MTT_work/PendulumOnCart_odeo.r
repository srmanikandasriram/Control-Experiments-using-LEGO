
%File: PendulumOnCart_odeo.r$

off echo$


% Begin Matrix MTTY$

mtty(1,1) := mttx4$

% End Matrix MTTY$

END;$

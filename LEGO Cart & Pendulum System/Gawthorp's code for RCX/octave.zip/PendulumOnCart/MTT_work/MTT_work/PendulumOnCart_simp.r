%% Reduce commands to simplify output for system PendulumOnCart (PendulumOnCart_simp.r)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% Version control history
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% $Id: rcs_header.txt,v 1.1 2000/12/28 09:13:38 peterg Exp $
% %% $Log: rcs_header.txt,v $
% %% Revision 1.1  2000/12/28 09:13:38  peterg
% %% Initial revision
% %%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ON ALLFAC; %Multiplicative factors
OFF DIV; %Polynomial division
OFF FACTOR; %Factorise polynomials
OFF LIST; %Each term on a new line
FOR ALL x,y LET pow(x,y) = x^y; %Readable pow function

r_p := 0;

END;

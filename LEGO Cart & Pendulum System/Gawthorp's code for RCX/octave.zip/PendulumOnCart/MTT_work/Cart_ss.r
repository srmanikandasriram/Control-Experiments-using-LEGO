mat((0),(0))$
%Steady-state values$
clear MTTx;$
MATRIX MTTx(2,1);$
clear MTTdX;$
MATRIX MTTdX(2,1);$
clear MTTy;$
MATRIX MTTy(1,1);$
clear MTTu;$
MATRIX MTTu(1,1);$
END;$

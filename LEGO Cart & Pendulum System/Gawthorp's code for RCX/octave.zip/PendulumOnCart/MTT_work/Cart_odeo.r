
%File: Cart_odeo.r$

off echo$


% Begin Matrix MTTY$

mtty(1,1) := mttx2$

% End Matrix MTTY$

END;$

function eqn = matrix2c(M,i,name,eqn);

  ## usage:  eqn = matrix2c(M,i,name,eqn);
  ## Writes equations for row i of matrix M with name "name"
  ## Used in controller2c.m
  ## Copyright (C) 2003,2004 by Peter J. Gawthrop
  ## $Id: matrix2c.m,v 1.3 2004/03/08 16:52:20 peterg Exp $

  if nargin<3
    name = "x";			# Blank string
  endif

  if nargin<4
    eqn = "";			# Blank string
  endif
  
  [n,m] = size(M);		# Dimensions
  
  for j = 1:m
    m_ij = M(i,j);
    if (m_ij>0)
      eqn = sprintf("%s\t+ %g*%s[%i]\n", eqn, m_ij, name, j-1);
    elseif (m_ij<0)
      eqn = sprintf("%s\t- %g*%s[%i]\n", eqn, -m_ij, name, j-1);
    endif
  endfor

endfunction
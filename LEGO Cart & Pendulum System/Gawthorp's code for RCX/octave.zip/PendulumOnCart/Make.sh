#! /bin/sh

## Design and build controller & display figures

cat<<EOF
Note that before figures can be plotted, the experiments must
be run using ../Example.m having copied Ustar.h and 
appropriate controller.c to RCX and 
make download
EOF

## Need to copy Cart_con.c to controller.c in RCX dir
## and make download
echo Making controller and figures for Cart
./MakeController.sh Cart 0.05 0.01

## Need to copy PendulumOnCart_con.c to controller.c in RCX dir
## and make download
echo Making controller and figures for PendulumOnCart
./MakeController.sh PendulumOnCart 0.05 0.05

## Figures for disturbance response
echo Making Disturbance figures.
octave -q Disturbance.m

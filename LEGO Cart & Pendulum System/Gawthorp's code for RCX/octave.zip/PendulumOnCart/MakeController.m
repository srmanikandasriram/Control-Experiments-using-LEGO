function MakeController (Name,lambda,sigma)

  ## usage:  MakeController (Name)
  ##
  ## 

  if nargin<1
    error("usage:  MakeController (Name)");
  endif

  if nargin<2
    lambda = 0.05;		# Control weighting
  endif
  
  if nargin<3
    sigma = 0.01;		# Measurement noise
  endif
  
  
  ## Makes the controller code
  sys = mtt2sys(Name); # System in octave form
  [n_x,n_z,n_u,n_y] = sysdimensions(sys);	# Sizes
  [A,B,C,D] = sys2ss(sys)

  ## LQ design
  ## Controller
  lambda_x = C'*C;
  lambda_u = lambda*eye(n_u);
  [K,P,c_poles] = lqr(A,B,lambda_x,lambda_u)

  sigma_x = eye(n_u);
  sigma_y = sigma*eye(n_y);
  [L,Q,o_poles] = lqe(A,eye(n_x),C,sigma_x,sigma_y)

  ## Closed-loop system
  g_ss = -C*((A-B*K)\B);
  c_sys = ss2sys(A-B*K, B/g_ss, [C;-K], [D;1/g_ss]);
  step(c_sys);

  [b_c_y,a_c_y] = sys2tf(sysprune(c_sys,1,1))	# Transfer function form
  [b_c_u,a_c_u] = sys2tf(sysprune(c_sys,2,1))	# Transfer function form

  ## Create equations
  eqns = controller2c (A,B,C,D,K,L,g_ss);

  ## Write to file
  filename = sprintf("%s_eqns.c",Name);
  fid = fopen(filename,"w");
  fprintf(fid,"%s", eqns);
  fclose(fid);

  ## Compare with data
  datafile = sprintf("%s_con.dat", Name);
  y_name = sprintf("%s_con_y", Name);
  u_name = sprintf("%s_con_u", Name);

  if exist(datafile)
    ## Compare with actual data
    eval(sprintf("load -force %s", datafile)) 

    dt = mean(diff(t))
    grid("off");
    title("");
    ylabel("");
    xlabel("Time (sec)");
    figure(3);
    y_sim = lcid_sim(a_c_y,b_c_y ,w,dt);
    plot(t,y,t,y_sim,t,w)
    figfig(y_name,"eps",0,1);

    figure(4);
    u_sim = lcid_sim(a_c_u,b_c_u ,w,dt);
    plot(t,u,t,u_sim)
    figfig(u_name,"eps",0,1);
  endif
  
endfunction

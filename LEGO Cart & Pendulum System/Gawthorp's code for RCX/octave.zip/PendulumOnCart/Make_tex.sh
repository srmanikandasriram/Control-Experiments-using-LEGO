#! /bin/sh
## Turns code into LaTeX

m2oct() {
 sed \
    -e 's/{\\it{\\\%endfunction}}/\\textbf{endfunction}/' \
    -e 's/{\\textbf{end}}{\\it{\\%for}}/\\textbf{endfor}/' \
    -e 's/{\\textbf{end}}{\\it{\\%if}}/\\textbf{endif}/' \
    -e 's/%/#/g'
}
## Octave stuff
rm Matlab/controller2c.m
octave2matlab controller2c
(cd Matlab; texifymatlab <controller2c.m  | m2oct >../controller2c.m.tex)

rm Matlab/matrix2c.m
octave2matlab matrix2c
(cd Matlab; texifymatlab <matrix2c.m | m2oct>../matrix2c.m.tex)

## C
texifyc++ <Cart_con.c >Cart_con.c.tex
texifyc++ <PendulumOnCart_con.c >PendulumOnCart_con.c.tex
texifyc++ <Cart_eqns.c >Cart_eqns.c.tex






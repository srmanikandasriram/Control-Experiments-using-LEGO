function eqn = matrix2c(M,i,name,eqn);
  ## usage:  eqn = matrix2c(M,i,name,eqn);
  ## Writes equations for row i of matrix M with name "name"
  ## Used in controller2c.m
  ## Copyright (C) 2003,2004 by Peter J. Gawthrop
  ## $Id: matrix2c.m,v 1.7 2004/04/05 08:24:33 peterg Exp $

  ## Defaults
  if nargin<3
    name = "x";			# Default name
  endif
  if nargin<4
    eqn = "";			# Blank string
  endif

  ## Create string containing equation of row i
  [n,m] = size(M);		# Dimensions
  for j = 1:m
    m_ij = M(i,j);
    if m_ij<0			# sign symbol
      pm = "-";
    else
      pm = "+";
    endif
    a = abs(m_ij);		# |m_i|
    if (a==1)
      eqn = sprintf("%s %s %s[%i]", eqn, pm, name, j-1);
    elseif (a!=0)
      eqn = sprintf("%s %s %g*%s[%i]", eqn, pm, a, name, j-1);
    endif
  endfor
endfunction
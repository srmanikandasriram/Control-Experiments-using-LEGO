/* 	$Id: motor_p.c,v 1.4 2002/01/26 13:10:30 peterg Exp $	 */
/* 	$Log: motor_p.c,v $
 * 	Revision 1.4  2002/01/26 13:10:30  peterg
 * 	*** empty log message ***
 *
 * 	Revision 1.3  2002/01/26 13:04:17  peterg
 * 	Minor changes
 *
 * 	Revision 1.2  2002/01/24 19:08:06  peterg
 * 	Tidied and changed sign for new configuration
 *
 * 	Revision 1.1  2002/01/23 21:26:46  peterg
 * 	Initial revision
 * */


/* motor_p.c */
/* Prop control using floats */
/* Uses motor + lego sensor with 5xgear. */

#define TICS_PER_REV 80

#include <unistd.h>
#include <dmotor.h>
#include <conio.h>
#include <dsensor.h>

int main(int argc, char **argv) 
{

  double k,kk;
  double u = 0;
  double w = 1;  /* rotation */
  double y;
  double error = 0;
  double gain = 5;
  double last = 20; /* sec */
  double dt = 20; /* msec */
  double period = 5; /* sec */
  double ticks;
  int u_int;
  int error_int;
  
  /* turn sensor on */
  ds_active(&SENSOR_3);
  ds_rotation_on(&SENSOR_3);

  /* calibrate sensor to 0 */
  ds_rotation_set(&SENSOR_3,0);
  msleep(100);



  /* Main loop */
  kk = 0;
  for(k=0;k<(last*1000)/dt;k++)
    {

      /* Square setpoint */
      kk++;
      if (kk>(1000*period)/dt) {
	kk = 0;
	w = -w;
      };
	     
      msleep(dt); 
      ticks = -ROTATION_3;	// Real version
      y = ticks/TICS_PER_REV;	// Motor output (revs)
 
      error = w - y;

       u = gain*error; 

      if (u>1) u = 1; 
      if (u<-1) u = -1; 

      if (u>0) {
	motor_c_dir(fwd);
	u_int = u*MAX_SPEED;
      }
      else
	{
	  motor_c_dir(rev);
	  u_int = -u*MAX_SPEED;
	};
	  

      motor_c_speed(u_int);	// Motor speed

      /* Display error */
      error_int = error*TICS_PER_REV;// Integer error
      lcd_int(error_int); 
    }

  motor_c_dir(off);
  return 0;
}




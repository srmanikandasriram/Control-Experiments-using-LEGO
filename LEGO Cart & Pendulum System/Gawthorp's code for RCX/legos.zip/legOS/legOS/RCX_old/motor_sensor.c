/* motor_sensor.c */
#include <unistd.h>
#include <dmotor.h>
#include <conio.h>
#include <dsensor.h>

int main(int argc, char **argv) 
{

  int k;

  /* turn sensor on */
  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  /* calibrate sensor to 0 */
  ds_rotation_set(&SENSOR_1,0);
  msleep(100);


  /*start the motor*/
  motor_a_dir(fwd);
  motor_a_speed(MAX_SPEED);

  /*slow down the motor gradually*/
  for(k=MAX_SPEED;k>=0;k--)
    {
      msleep(100); /* Hang about */
      /*slow the motor down a notch*/
      motor_a_speed(k);
      /* Display rotation */
      lcd_int(-ROTATION_1);
    }

  motor_a_dir(off);
  return 0;
}

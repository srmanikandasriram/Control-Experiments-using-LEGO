/* 	$Id: lnptest_rcx.c,v 1.2 2002/04/11 08:32:05 peterg Exp peterg $ */
/* 	$Log: lnptest_rcx.c,v $
 * 	Revision 1.2  2002/04/11 08:32:05  peterg
 * 	Initial version
 *
 * 	Revision 1.1  2002/04/11 07:58:34  peterg
 * 	Initial revision
  * */


/* lnptest_rcx.c */
/* Simple network test */

#include <unistd.h>
#include <conio.h>
#include <lnp.h>

/* Port definitions  */
#define MY_PORT 2
#define DEST_HOST 0x8
#define DEST_PORT 0x7
#define DEST_PORT_2 0x8
#define DEST_ADDR ( DEST_HOST << 4 | DEST_PORT )
#define DEST_ADDR_2 ( DEST_HOST << 4 | DEST_PORT_2 )

//void addr_handler(const unsigned char *data, unsigned char length, unsigned char src);

int main(int argc, char **argv) 
{
  char *r2p, *r2r, *p2r;
  int result;

  //  lnp_addressing_set_handler (MY_PORT, addr_handler);

	  
  r2p = "r2p";			/* RCX to PC string */
  r2r = "r2r";			/* RCX to RCX string */
  p2r = "p2r";			/* PC to RCX string */


  cputs("start");			/* Show start */
  msleep(1000);
  cputs(r2r);
  msleep(1000);
  result = lnp_addressing_write(r2p, 4, DEST_ADDR, MY_PORT);
  lcd_int(result);			/* Show result */
  msleep(1000);
  cputs("end");
  return 0;
}

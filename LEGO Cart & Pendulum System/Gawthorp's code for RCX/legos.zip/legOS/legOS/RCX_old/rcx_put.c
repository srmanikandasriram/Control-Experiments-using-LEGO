//
// Test of sending reals as strings
//


#include <lnp.h>
#include <conio.h>
#include <sys/irq.h>
#include <sys/h8.h>
#include <tm.h>
#include <dkey.h>
#include <unistd.h>
#include <lnp-logical.h>
#include <sys/lnp-logical.h>
#include <string.h>
#include <float.h>

/* Use integers - comment out to use strings */
#define USE_INTEGERS 1

#define LEN 100
#define X_LEN 4
#define INTERVAL 0

#ifdef USE_INTEGERS
/* Define the putint function */
#include "putint.c"
#else
/* Define the function num2str */
#include "num2str.c"

#endif

int main(int argc, char *argv[])
{
  double X[X_LEN];

/*   char s; */


#ifdef USE_INTEGERS
  int count=0;
  int I[4];
#else
  int count=0;
  signed char result;
  unsigned char data[LEN];
  int i;
#endif

  lnp_logical_range(0);
  lcd_clear();
  cputs("WAIT");
  msleep(1000);
  cputs("RUN");

  X[0] = 1.0;
  
#ifdef USE_INTEGERS
  while(1)
    {
      I[0] = count++;
      I[1] = 2*I[0];
      I[2] = 3*I[0];
      I[3] = 4*I[0];
      putint(I,4);
    };
#else

  while(1)
    {
      strcpy(data,"............................................................");
      data[0] = count + ZERO;
      for (i=0;i<X_LEN-1;i++) X[i+1] = X[i]*2;
      num2str(data,X,X_LEN);
      result = lnp_integrity_write(data,strlen(data)+1);
      msleep(INTERVAL);
      count++;
      if (count>9) count=0;
      X[0] = 0.9*X[0];
    }
#endif
  cputs("STOP");
  return 0;
}


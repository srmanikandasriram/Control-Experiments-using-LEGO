/* robot3.c
*
* These messages are also used by the Java program robot3.Controller<BR>
* --<BR>
*<BR>
* Messages, PC => RCX:<BR>
* --<BR>
* R = reset, motor powers to 0 and motors to float<BR>
* S = stop (brake, full voltage to motors)<BR>
*<BR>
* Mxaybzc = Set motor state and speed, x=speed for A, a=state for A,<BR>
*			 y=speed for B, b=state for B...<BR>
*<BR>
* Ax = set motor A's power to the value of x (binary, 0..255)<BR>
* Bx = set motor B's power to the value of x (binary)<BR>
* Cx = set motor C's power to the value of x (binary)<BR>
*<BR>
* 1x = set motor A state to x, (0=off (float), 1=forward, 2=reverse, 3=brake;<BR>
*       defined in robot2.Controller.[FLOAT|FORWARD|REVERSE|BRAKE] )<BR>
* 2x = set motor B state to x<BR>
* 3x = set motor C state to x<BR>
*<P>
* -----------------------------------------------------------------------------<BR>
*<BR>
* When the bumper (SENSOR_2) hits something, the robot will also stop (brake).<BR>
*
* @author Asmo Soinio (asoinio@abo.fi)
*/
#include <conio.h>
#include <unistd.h>
#include <string.h>
#include <lnp.h>
#include <dmotor.h>
#include <dsensor.h>
#include <time.h>

unsigned long m_index=0;

/* Brakes with all the motors */
void stop_robot() {
	motor_a_dir(brake);
	motor_b_dir(brake);
	motor_c_dir(brake);
	motor_a_speed(255);
	motor_b_speed(255);
	motor_c_speed(255);
}

void my_integrity_handler(const unsigned char *data, unsigned char len)
{
	m_index++;

	if(data[0]=='S') {
		stop_robot();
	}
	else if(data[0]=='R') {
		motor_a_dir(off);
		motor_b_dir(off);
		motor_c_dir(off);
		motor_a_speed(0);
		motor_b_speed(0);
		motor_c_speed(0);
	}
	else if(data[0]=='M') {
		motor_a_dir(data[2]);
		motor_b_dir(data[4]);
		motor_c_dir(data[6]);
		motor_a_speed(data[1]);
		motor_b_speed(data[3]);
		motor_c_speed(data[5]);
	}
	else if(data[0]=='A') {
		motor_a_speed(data[1]);
	}
	else if(data[0]=='B') {
		motor_b_speed(data[1]);
	}
	else if(data[0]=='C') {
		motor_c_speed(data[1]);
	}
	else if(data[0]=='1') {
		motor_a_dir(data[1] );
	}
	else if(data[0]=='2') {
		motor_b_dir(data[1] );
	}
	else if(data[0]=='3') {
		motor_c_dir(data[1] );
	}

}

int main()
{
	lnp_integrity_set_handler(my_integrity_handler);

	while(1)
	{
		cputw(m_index);
	}
	return 0;
}

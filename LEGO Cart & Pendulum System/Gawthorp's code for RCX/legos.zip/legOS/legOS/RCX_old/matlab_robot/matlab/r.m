% Uses robot_move_to_end to make the robot to move to the end of the
% line and then plots the results

report=robot_move_to_end(0.10);
figure;
plot(report(:,1),report(:,3)/255,'-',report(:,1),report(:,2),'-',report(:,1),report(:,5)/255,'-',report(:,1),report(:,6)/255,'-');
axis([report(1,1),max(report(:,1)),0,1]);
legend('Strongness of the line','Line x','Motor level A','Motor level B')
disp('Analyze frequency of the whole sample (sample/sec):');
disp(length(report(:,1))/(max(report(:,1))-min(report(:,1))));

disp('Analyze frequency of the 50% first samples (sample/sec):');
n=round(length(report(:,1))/2);
disp(n/(max(report(1:n,1))-min(report(1:n,1))));
% This function adjust the y_to_z-function's arguments so that 
% it can correctly convert picture y-values to z values
%
% The results are stored in the global G_KAB-value and also returned
%
% To use this function place the robot to the first, thinnest, line of the
% measurement paper (with lines at 10 cm distances) and make sure the 
% robot is perpendicular to the lines. To print the measurement paper
% print the image \matlab_robot\docs\10cm_paper.gif with 10 dpi.

function G_KAB=adjust_z
global G_KAB;

grab=vfm('grab');

im=uint8(0.30*double(grab(:,:,1))+0.59*double(grab(:,:,2))+0.11*double(grab(:,:,3)));
clear B;
B(:,:,1) = im;
B(:,:,2) = im;
B(:,:,3) = im;

close all;

figure;
image(B);
title('Black and white -version of the grabbed image');

im2=double(im<160);


k=paramlabel(im2);
figure;
image(k*5);
title('The objects found in the grabbed picture and the horisontal lines detected');

n=max(max(k));

clear object;

s=size(im);
height=s(1);
width=s(2);
the_size=height*width;

for(I=1:n)
    [y x]=find(k==I);
    object(I,1)=mean(y)/height; % the y-mean value for all the pixels in the object
    object(I,2)=length(y)/the_size; %number of pixels in the object / size of the image
    object(I,3)=(max(y)-min(y))/height; % the height of the object
    object(I,4)=(max(x)-min(x))/width; % the width of the object    
end

object=sortrows(object); %sorted by y-values

I=length(object);
VI=1;
clear vlines;

while(VI<6 & I>0)
    if(object(I,2)>0.005 & object(I,4)>.5 & (object(I,4)./object(I,3))>10)
        vlines(VI)=object(I,1);
        H=line([1 width],[vlines(VI)*height vlines(VI)*height]);
        set(H,'Color','white');
        VI=VI+1;
    end
    I=I-1;
end

if(length(vlines)<5)
    error('All 5 lines were not detected, is the image unclear?!');
end


[G_KAB, esum, exitflag]=fminsearch(@error_sum,[10 0 0],[],vlines)

if(exitflag~=1)
    error('The optimization did not converge!');
end

figure;
plot(vlines(5):0.01:1,y_to_z(vlines(5):0.01:1),'-',vlines,10:10:50,'o-');
ylabel('z (cm)');
xlabel('y (propotionell to the height of the image)');
legend('function y\_to\_z(y)','Measures');


% counts the sum of square of errors between z=10:10:50 and 
% the function y_to_z, z=k/(y+b)+a where k=ka(1), a=ka(2), b=ka(3) and y=meas
function error=error_sum(local_kab, meas)
z=y_to_z(meas, local_kab);
error=sum(((10:10:50)-z).^2);

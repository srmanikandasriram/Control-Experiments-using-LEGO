function draw_map(objects)
% 1:Unknown       
% 2:Black_2x2x1   
% 3:Black_2x2x3   
% 4:Black_4x4x2   
% 5:White_Round   
% 6:Green_Triangle
% 7:Red_Round     
% 8:Wall          
% 9:Small_Ignored 
zoom=1.5
symbols_x=[.01,.01,.01,.01,.01,.01;...
        .01,.01,-.01,-.02, -.02,0;...
        .01,.01,-.01,-.02, -.02,0;...
        .02,.02,-.02,-.03, -.03,0.01;...
        -.02,.0,.02,.02,.0,-.02;...
        .03,.0,-.03,-.03,.03,.03;...
        -.02,.0,.02,.02,.0,-.02;...
        .5/zoom,.5/zoom,-.5/zoom,-.5/zoom,.5/zoom,.5/zoom];
symbols_y=[.01,.01,.01,.01,.01,.01;...
        .01,0,0,.01,.02,.02;...
        .03,0,0,.01,.04,.04;...
        .02,0,0,.01,.03,.03;...
        .03,.04,.03,.01,.0,.01;...
        .02,.0,.02,.025,.025,.02;...
        .03,.04,.03,.01,.0,.01;...
        .05/zoom,0,0,.05/zoom,.05/zoom,.05/zoom];
symbol_c=[.5 .5 .5;...
          0 0 0;...
          0 0 0;...
          0 0 0;...          
          .98 .98 .98;...
          0 .6 0;...
          1 0 0;...
          .9 .8 .7];

% robot_x=[.1,.1,-.1,-.1];
robot_y=[0,.01,.01,0];
robot_c=[1 1 0];

mark_x=[.01,-.01,.01,-.01];
mark_y=[-.01,.01,.01,-.01];
mark_c=[0 0 1];


ind=1;
for I=1:length(objects), 
    if(objects(I).type~=9 & objects(I).type~=1)
        Z(ind)=objects(I).z;
        X(ind)=objects(I).prop_x; 
        T(ind)=objects(I).type;
        ind=ind+1;
    end
end

s=max(max(Z),max(X)-min(X))*zoom

figure
title('Map of the objects, the robot is located in the bottom of the map');
hold on

% draws the robot:
patch([10 10 -10 -10], 0+robot_y*s,robot_c);

% draws the vision field of the robot 
% (see "Vision field of the robot.doc" for details)
vlen=max(Z)*.8;
H=line([-6.5-sin(20*pi/180)*vlen -6.5 6.5 6.5+sin(20*pi/180)*vlen],[8+cos(20*pi/180)*vlen 8 8 8+cos(20*pi/180)*vlen]);
set(H,'Color',[0 .8 1]);
set(H,'LineStyle',':');

for(I=1:length(Z))
    patch(X(I)+symbols_x(T(I),:)*s, Z(I)+symbols_y(T(I),:)*s,symbol_c(T(I),:));
    patch(X(I)+mark_x*s, Z(I)+mark_y*s,mark_c);    
end
xlabel('X (cm)');
ylabel('Z (cm)');
axis equal;
hold off

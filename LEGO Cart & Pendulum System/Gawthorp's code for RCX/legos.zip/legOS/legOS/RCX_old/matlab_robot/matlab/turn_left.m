function turn_left(speed)

global controller;

controller.setAllMotors(speed*.5,robot3.Controller.REVERSE,speed,robot3.Controller.FORWARD,0,0);

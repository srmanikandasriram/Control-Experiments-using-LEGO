function max_der=analyze_hline
J=vfm('grab');
image=J(:,:,1);
s=size(image);
y1=s(1)-11;
y2=s(1)-1;
max_der=median_max_ver_der(image, y1, y2);
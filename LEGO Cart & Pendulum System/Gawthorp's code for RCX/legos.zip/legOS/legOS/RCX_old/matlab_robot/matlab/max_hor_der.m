% The function max_hor_der counts the maximum of horisontal 
% derivatives for each vertical line of an image. 
% If the input image has many color-layers,
% the derivative is counted for each of them separately.
%
% ymin and ymax determin the rows from which the derivatives
% are calculated. 
%
% The returning array will be of size [1 x image-width x color-depth]
%
% USAGE: hd=max_hor_der(image, ymin, ymax)
%
% The function is a MEX-file for MATLAB, the source code is in the .c-file.
% appends the type, red, green, blue, wideness and prop_height -values
% for the objects to the file
%
% USAGE: save_objects(filename, objects)
function save_objects(filename, objects)

fid=fopen(filename,'a');

for I=1:length(objects)
    fprintf(fid,'%% type\tred\t\tgreen\t\tblue\t\twideness\tprop_size\n');
    fprintf(fid,'%d\t%e\t%e\t%e\t%e\t%e\n', objects(I).type, objects(I).red, objects(I).green,...
        objects(I).blue, objects(I).wideness, objects(I).prop_size);
    
end

fclose(fid);

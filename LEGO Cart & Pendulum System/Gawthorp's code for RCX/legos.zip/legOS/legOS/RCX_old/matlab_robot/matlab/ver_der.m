% The function ver_der counts the vertical derivatives
% of an image. If the input image has many color-layers,
% the derivative is counted for each of them separately.
%
% ymin and ymax determin the rows from which the derivatives
% are calculated. ymin > 1, ymax < image-height - 1
%
% The returning array will be of size [image-width x (ymax-ymin) x color-depth]
%
% USAGE: hd=hor_der(image, ymin, ymax)
%
% The function is a MEX-file for MATLAB, the source code is in the .c-file.
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
% Grabs an image and analyzes the objects in it
% 
% [object grab]=analyze_objects(debug, only_blacks, ignore_smaller_than);
%
% grab = the image grabbed
%
% no need to define debug, if defined and true, the function will
% show what it has done
%
% For object analysis I used resolution 352x280.
%
% if only_blacks os defined, the function will threshold the image
% with a very low value so that only really black objects will be
% detected
%
% If ignore_smaller_than is defined objects smaller than it's value
% (number of pixels) are ignored
%
% object=an array of structure with following data:
%
%     x
%     y
%     z
%     prop_x
%     size
%     height
%     width
%     red
%     green
%     blue
%     wideness
%     prop_size
%     type=O_UNKNOWN
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
function [object, grab]=analyze_objects(debug, only_blacks, ignore_smaller_than);

dbg=0;
try
    if(debug)
        dbg=1;
    end
end

grab=double(vfm('grab'));

% blur the image, takes about 40 seconds!! (for 160x120)
% grab2=double(grab);
% 
% s=size(grab);
% tic
% for Y=2:s(1)-1
%     Y
%     for X=2:s(2)-1
%          for I=1:3
%              grab(Y,X,I) = mean(...
%                  [grab2(Y-1,X-1,I) grab2(Y-1,X,I) grab2(Y-1,X+1,I)...
%                  grab2(Y,X-1,I) grab2(Y,X,I) grab2(Y,X+1,I)...
%                  grab2(Y+1,X-1,I) grab2(Y+1,X,I) grab2(Y+1,X+1,I)]);
%         end
%     end
% end
% toc

% convert to gray-image, green is overweighted, blue is discarded!!!
% normal=.30 .59 .11
im=0.30*double(grab(:,:,1))+0.70*double(grab(:,:,2));

if(dbg)
	figure(1)
	for RGB=1:3
        SUBPLOT(2,2,RGB);
        image(grab(:,:,RGB));
        colormap(gray(255));
	end
end


if(dbg)
	figure(2)
	SUBPLOT(2,2,1)
	image(grab/255);
	SUBPLOT(2,2,2)
	image(im);
end

% Default values:
threshold=mean(mean(im))*.75
threshold2=240
%threshold2=max(max(im))*.94
try
    if(only_blacks)
        threshold=90;
        threshold2=256;
    end
end
im2=double(im<threshold | im>threshold2);

if(dbg)
	SUBPLOT(2,2,3)
	image(im2*128);
end

k=paramlabel(im2);

% add the missing borders to the label-index image:
s=size(k);
k=[zeros(1,s(2)); k];
k=[zeros(s(1)+1,1) k];

n=max(max(k));

if(dbg)
	SUBPLOT(2,2,4)
	image(k*(255/n));
	colormap(jet(255));
end

clear object;

s=size(im);
height=s(1);
width=s(2);
the_size=height*width;

ignored=0;
limit=0;

try
    limit=ignore_smaller_than;
end

for(I=1:n)
    bw=(k==I);
    [y x]=find(bw);
    if (length(y)<limit) 
        ignored=ignored+1;
    else
        object(I-ignored).size=length(y)/the_size; %number of pixels in the object / size of the image
        object(I-ignored).height=(max(y)-min(y))/height; % the height of the object
        object(I-ignored).width=(max(x)-min(x))/width; % the width of the object    

        oy=max(y); % the y value for the object (bottom of the object)
        miny=min(y);
        minw=object(I-ignored).width*width*.7;
        while (sum(bw(oy,:))<minw & oy>miny )
            oy=oy-1;
        end
        if(oy==miny) oy=max(y); end
        object(I-ignored).y=oy/height;
        
        object(I-ignored).x=min(x)/width; % the x value for the object    
        object(I-ignored).z=y_to_z(object(I-ignored).y); % the z value for the object (bottom of the object)
        
        object(I-ignored).prop_x=x_to_prop_x(mean(x)/width,object(I-ignored).y); % the propotional x value for the object
        object(I-ignored).red=sum(sum(grab(:,:,1).*bw))/length(y);
        object(I-ignored).green=sum(sum(grab(:,:,2).*bw))/length(y);
        object(I-ignored).blue=sum(sum(grab(:,:,3).*bw))/length(y);
        object(I-ignored).wideness=object(I-ignored).width/object(I-ignored).height;
        object(I-ignored).prop_size=prop_size(object(I-ignored).size, object(I-ignored).y);
        object(I-ignored).type=1;
    end
end

if(dbg)
    title(['The objects found in the grabbed picture (' int2str(ignored) ' ignored)']);
    
    SUBPLOT(2,2,1)
	plot_object_data_unknown(object, width, height);
	
	SUBPLOT(2,2,4)
	plot_object_data_unknown(object, width, height);
end
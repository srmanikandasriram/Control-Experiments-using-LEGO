function [edges, vertical, horisontal]=detect_edges(image)

s=size(image);

hd=double(hor_der(image,1,s(1)));
vd=double(ver_der(image,2,s(1)-1));

vertical=zeros(s);

vertical(2:s(1)-1,:,:)=vd;
horisontal=hd;

hd(2:s(1)-1,:,:)=hd(2:s(1)-1,:,:)+vd;

%mn=min(min(min(hd)));
mx=max(max(max(hd)));

edges=hd*255/mx;
vertical=vertical*255/mx;
horisontal=horisontal*255/mx;
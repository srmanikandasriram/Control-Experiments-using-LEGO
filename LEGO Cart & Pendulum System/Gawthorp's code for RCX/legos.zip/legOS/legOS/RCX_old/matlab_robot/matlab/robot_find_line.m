function [x, mx]=robot_find_line(clockwise)

global controller;

EPSILON=0.02;
MIDDLE=0.5;

controller.brakeAll;
[x mx]=analyze_vline;

% If line is not found in the picture, turn clockwise/anti clockwise...
if(mx<60)
    if(clockwise) turn_right(255)
    else turn_left(255)
    end
end

% ...until the line is found
while (mx<60)
    [x mx]=analyze_vline;
end
    
% controller.brakeAll;
x;
mx;

%fiine adjustment to get the line in the middle of the image
if(x<MIDDLE-EPSILON)
    turn_left(30)
    disp('Turning left');
    while(x<MIDDLE)
        [x mx]=analyze_vline;
    end
elseif(x>MIDDLE+EPSILON)
    turn_right(30)
    disp('Turning right');
    while(x>MIDDLE)
        [x mx]=analyze_vline;
    end
end

controller.brakeAll;

[x mx]=analyze_vline;

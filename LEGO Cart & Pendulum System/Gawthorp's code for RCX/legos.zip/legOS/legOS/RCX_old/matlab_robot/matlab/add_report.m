% Adds values for current_time (toc), x, max_der_hor, max_der_ver, 
%  controller.getMotorLevel(0) and controller.getMotorLevel(1)
%  to the end of the report-variable.
% 
% usage:
%  add_report(x, max_der_hor, max_der_ver)
function add_report(x, max_der_hor, max_der_ver)
global index controller report;

report(index,:)=[toc x double(max_der_hor) double(max_der_ver)...
        controller.getMotorLevel(0) controller.getMotorLevel(1)];
index=index+1;

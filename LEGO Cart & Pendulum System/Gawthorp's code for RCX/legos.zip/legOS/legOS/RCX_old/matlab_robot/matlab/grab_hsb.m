I=vfm('grab');

s=size(I)

hsb=zeros(s);

tic
for Y=1:s(1)
    for X=1:s(2)
        hsb(Y,X,:)=java.awt.Color.RGBtoHSB( ...
            I(Y,X,1), I(Y,X,2), I(Y,X,3), [0 0 0]);
    end
end
toc

close all;

for X=1:3
    figure;
    image(hsb(:,:,X)*255);
    colormap('gray');
end

figure;
image(hsb);
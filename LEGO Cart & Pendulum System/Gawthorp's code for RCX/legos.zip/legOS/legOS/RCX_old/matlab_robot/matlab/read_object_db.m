% Initializes the object database. This should be done before using 
% analyze_objects. get_object_type will run this script if
% object_db is undefined.
%
% Reads the contents of the file object_db.txt and saves the results to
% the global variable object_db. Global O_ARG_WEIGHTS and O_TYPE_NAMES
% are also defined by this script.
%
% O_ARG_WEIGHTS will present the weights given to each argument when
% trying to match an object to the object database.
%
% Also reads in values for G_KAB and G_SIZE_ABC used for counting object z and
% objects propotional sizes.
global object_db O_TYPE_NAMES O_ARG_WEIGHTS;

O_TYPE_NAMES=strvcat('Unknown','Black\_2x2x1','Black\_2x2x3','Black\_4x4x2','White\_Round','Green\_Triangle','Red\_Round','Wall','Small\_Ignored');

load object_db.txt;

temp=max(object_db)-min(object_db);

temp=temp/max(temp);

O_ARG_WEIGHTS=temp(2:6).*[1 1 1 .5 .5];

load G_KAB;
load G_SIZE_ABC;

% 1:Unknown       
% 2:Black_2x2x1   
% 3:Black_2x2x3   
% 4:Black_4x4x2   
% 5:White_Round   
% 6:Green_Triangle
% 7:Red_Round     
% 8:Wall          
% 9:Small_Ignored 
% otype=get_object_type(object)
% 
% Returns the type of the object. It is determined
% by matching the red, green, blue, wideness and prop_size
% components to the object_db-database.
function [otype, otypename]=get_object_type(object)
global object_db O_TYPE_NAMES O_ARG_WEIGHTS;

minu=zeros(size(object_db));
weight=ones(size(object_db));

args=[object.red object.green object.blue...
        object.wideness object.prop_size];

for I=1:length(object_db)
    minu(I,2:6)=args;
%    weight(I,2:6)=[1 1 1 .01 .01];
    weight(I,2:6)=O_ARG_WEIGHTS;    
end
weight;
r=sum( ((object_db-minu)./weight).^2,2);

rmin=min(r);
otype=object_db(find(r==rmin),1);
t=object_db(find(r==rmin),:);
((args-t(2:6))./O_ARG_WEIGHTS).^2;

otypename=O_TYPE_NAMES(otype);
% Grabs an image and analyzes the objects in it
%
% Uses get_object_type to determine the type of each object,
% otherwise does the same as analyze_objects.
%
% If blacks_only if defined and true, only really dark objects
% are analyzed.
%
% For object analysis I used resolution 352x280.
%
% If object_db doesn't exist in the memory, the script
% read_object_db will be executed.
%
% USAGE: objects=analyze_object_types(blacks_only)
%
% See also: ANALYZE_OBJECTS
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
function object=analyze_object_types(blacks_only);
global O_TYPE_NAMES object_db;

try
    object_db(1);
catch
    read_object_db
end

close all;

b=0;
try
    b=blacks_only;
end

[object grab] = analyze_objects(1,b);

figure;
image(grab/255);
s=size(grab);
height=s(1);
width=s(2);

for(I=1:length(object))
    object(I).type=get_object_type(object(I));
    H=line([object(I).x*width;...
            object(I).x*width;...
            object(I).x*width+object(I).width*width;... 
            object(I).x*width+object(I).width*width;...
            object(I).x*width;...
        ],...
        [object(I).y*height;...
            object(I).y*height-object(I).height*height;...
            object(I).y*height-object(I).height*height;...
            object(I).y*height;...
            object(I).y*height]);
    set(H,'Color','white');
    H=text(object(I).x*width,object(I).y*height+8,[int2str(I) ': ' O_TYPE_NAMES(object(I).type,:)] );
    set(H,'Color','white');
end

draw_map(object);
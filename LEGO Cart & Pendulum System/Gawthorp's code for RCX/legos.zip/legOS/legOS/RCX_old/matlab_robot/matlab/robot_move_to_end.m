function report=robot_move_to_end(EPSILON)

global controller index report;

SPEED_NORMAL_A=40;
SPEED_NORMAL_B=150;
SPEED_CHANGE_A=40;
SPEED_CHANGE_B=80;

MIDDLE=0.5;

report=[0, 0, 0, 0, 0, 0];

index=1;

controller.brakeAll;
tic;
mx=analyze_hline;

add_report(0,0, mx);

LIMIT=80;

while(mx<LIMIT)
    [x temp image]=analyze_vline;
    if (temp>80 & x<MIDDLE-EPSILON)
        set_motors_fwd(SPEED_NORMAL_A-SPEED_CHANGE_A,SPEED_NORMAL_B+SPEED_CHANGE_B);
    elseif (temp>80 & x>MIDDLE+EPSILON)
        set_motors_fwd(SPEED_NORMAL_A+SPEED_CHANGE_A,SPEED_NORMAL_B-SPEED_CHANGE_B);
    elseif (temp>80 & abs(x-MIDDLE)<=EPSILON)
        set_motors_fwd(SPEED_NORMAL_A,SPEED_NORMAL_B);
    end
    mx=median_max_ver_der(image, 109, 119);
    add_report(x, temp, mx);
end

pause(0.5);
controller.brakeAll;
mx=analyze_hline;
add_report(0,0, mx);


% Follows the line in the floor using robot_find_line
% and robot_move_to_end, the version with an ON/OFF-regulator
%
% If the script robot_init hasn't been ran, 
% this script initializes the robot by running it.
if (~length(who('global','G_KAB')))
    robot_init
end

close all;
while(1)
	robot_find_line(0);
	robot_move_to_end(0.1);
	robot_find_line(1);
	robot_move_to_end(0.1);    
end
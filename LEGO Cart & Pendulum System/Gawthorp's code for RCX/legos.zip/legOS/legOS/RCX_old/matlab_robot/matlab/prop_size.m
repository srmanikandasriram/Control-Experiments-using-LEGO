% psize = prop_size(size, y)
% OR
% psize = prop_size(size, y, size_abc)
%
% is size_abc is not defined, the global G_SIZE_ABC
% is used (the one adjusted with adjust_prop_size)
%
% The formula is:
%   psize=sqrt(a*size)./(b*y+c);
function psize=prop_size(size, y, size_abc)
global G_SIZE_ABC;
try 
    a=size_abc(1);
    b=size_abc(2);
    c=size_abc(3);
catch
    try
        a=G_SIZE_ABC(1);
        b=G_SIZE_ABC(2);
        c=G_SIZE_ABC(3);
    catch
        error('The global G_SIZE_ABC is not defined, please load it with "load G_SIZE_ABC"');
    end
end    
psize=sqrt(a*size)./(b*y+c);
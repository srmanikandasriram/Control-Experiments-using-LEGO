% Zets the levels for the motors if the new motor
% levels differs from the current ones with more than 5 of if the new states
% of the motors differ from the old ones.
%
% If the levels are both 0, the robot is set to BRAKE.
%
% If a level is negative, the motor will be set to reverse-mode.
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002

function set_motors(level_a,level_b)
global controller;

mode_a=robot3.Controller.FORWARD;
mode_b=robot3.Controller.FORWARD;

last_sent_time=clock;
if(level_a==0 & level_b==0)
    if(controller.getMotorState(0)~=robot3.Controller.BRAKE | ... 
            controller.getMotorState(1)~=robot3.Controller.BRAKE | ...
            controller.getMotorLevel(0)~=robot3.Controller.MOTOR_LEVELS | ...
            controller.getMotorLevel(1)~=robot3.Controller.MOTOR_LEVELS)
        controller.brakeAll;
    end
    return
end

if (level_a<0) 
    level_a=-level_a; 
    mode_a=robot3.Controller.REVERSE;
end
if (level_b<0) 
    level_b=-level_b; 
    mode_b=robot3.Controller.REVERSE;
end
if (level_a>robot3.Controller.MOTOR_LEVELS) level_a=robot3.Controller.MOTOR_LEVELS; end
if (level_b>robot3.Controller.MOTOR_LEVELS) level_b=robot3.Controller.MOTOR_LEVELS; end

if(mode_a~=controller.getMotorState(0) | mode_b~=controller.getMotorState(1)...
    | abs(level_a-controller.getMotorLevel(0))>5 | abs(level_b-controller.getMotorLevel(1))>5 )
	controller.setAllMotors(level_a,mode_a,...
        level_b,mode_b,0,0);
end

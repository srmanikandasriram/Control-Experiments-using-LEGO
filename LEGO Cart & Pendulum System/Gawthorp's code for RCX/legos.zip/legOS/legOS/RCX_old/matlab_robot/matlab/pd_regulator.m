% u=pd_regulator(Kp, Kd, y, old_y, x, toc_old)
function u=pd_regulator(Kp, Kd, y, old_y, x, toc_old)

% dt=(toc-toc_old), dy=y-old_y
u=-Kp*(y-x)-Kd*((y-old_y)/(toc-toc_old));
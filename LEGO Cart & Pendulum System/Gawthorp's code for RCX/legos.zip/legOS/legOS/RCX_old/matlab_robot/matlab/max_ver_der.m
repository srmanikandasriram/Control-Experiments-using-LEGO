% The function median_max_ver_der counts the median of
% maximum of vertical derivatives for each vertical line of an image. 
% If the input image has many color-layers,
% the derivative is counted for each of them separately.
%
% ymin and ymax determin the rows from which the derivatives
% are calculated. 
%
% The returning array will be of size [color-depth]
%
% USAGE: hd=median_max_ver_der(image, ymin, ymax)
%
% The function is a MEX-file for MATLAB, the source code is in the .c-file.
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
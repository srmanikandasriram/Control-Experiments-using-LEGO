% Analyzes the image I to see if it contains horisontal lines.
%
% The max_der depends on contrasts in the image, with my webcam in a 
% robot I get:
% max_der<30 => no line,  max_der>90 => strong horisontal line
%
function max_der=has_hor_line(I, y_limit, y_limit_2)

s=size(I);
if(length(s)==3)
    colordepth=s(3);
else 
    colordepth=1;
end
der=ver_der(I,y_limit, y_limit_2);

for RGB=1:colordepth
    max_der(RGB)=median(double(max(der(:,:,RGB))));
end
% Grabs an image and finds the position of the trolley in the image
% 
% [x z strength grab]=detect_trolley(debug)
%
% x and z are in cm
%
% Strength depends on the lightness of the image, with my webcam i get:
%
% strength>70 => trolley detected (~100 when it's near)
% strength<60 => propably no trolley detected
%
% no need to define debug, if defined and true, the function will
% show what it has done.
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
function [x, z, strength, grab, s, ox, oy]=detect_trolley(debug)

% just a counter:
global g_detect;
g_detect=g_detect+1;

dbg=0;
if nargin > 0
    dbg=debug;
end

if (dbg) tic
end
grab=vfm('grab');
s=size(grab);

green=double(grab(:,:,1))-double(grab(:,:,2));
strength=max(max(green));
limit=strength*0.7;
[gy gx]=find(green>limit);
if(length(gy)==0 | length(gx)==0)
    x=0;
    z=0;
    strength=-1;
    return;
end

ox=mean(gx);
oy=max(gy);

x = x_to_prop_x(ox/s(2),oy/s(1)); % the propotional x value for the object

z = y_to_z(oy/s(1));


if (dbg) 
    toc
	close all
	
	figure; imagesc(grab);
    hold on;
    plot(ox,oy,'*');
    hold off;
	figure; imagesc(green);
    hold on;
    plot(ox,oy,'*');
    hold off;
	figure; imagesc(green>limit);
    hold on;
    plot(ox,oy,'*');
    hold off;
end

% This script initializes the robot-controller and some global variables
% used to control the robot
%
% The functions robot_travel, robot_travel_v2 and follow_trolley
% run this script automatically if it hasn't already been ran.
%
% About the robot:
% 
% for the robot_travel, robot_move_to_end and so on i had the camera
% installed in the following position:
%
% ,---.
% | < |--- with an 8 brick to the 5 th hole in the robots long brick
% | O |
% | O |
% | < |-- end of the robots long brick
% `---'
%
% This makes the camera to point down about 30 degrees from horisontal axis
%
% ----
% For detect_object_types and follow_trolley i had the camera installed in
% the following position:
%
% ,---.
% | O |
% | < |--- with an 8 brick to the 6 th hole in the robots long brick
% | O |
% | < |-- end of the robots long brick
% `---'
%
% This makes the camera to point down about 20 degrees from horisontal axis
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
global controller last_sent_time;

load G_KAB
load G_SIZE_ABC

last_sent_time=clock;

controller = robot3.Controller(1);

disp('Set the resolution to 160x120!!!!!');
vfm;
vfm('configformat');
% Calculate Gradient
% input:
% 		       img: image data
% 	snakeGradientSigma: Gaussian's Sigma
% output: 
%	gradient normalized to 0-255;

function gradient=calgrad(im,snakeGradientSigma)

% Calculate a normal distribution with a standard deviation of sigma.
% Cut off when tails reach 1% of the maximum value.
i=0;
maxval = 1/(sqrt(2*pi)*snakeGradientSigma);
gi = maxval;
g = [gi];
while gi >= 0.01*maxval
      gi = maxval * exp(-0.5*i^2/snakeGradientSigma^2);
      g = [gi g gi];
      i = i + 1;
end

% Calculate the derivative of a normal distribution with a standard
% deviation of sigma.
% Cut off when tails reach 1% of the maximum value.
i = 1;
maxval = 0;
dgi = [maxval];
dg = [dgi];
while dgi >= 0.01*maxval
      dgi = i / (sqrt(2*pi) * snakeGradientSigma^3) * ...
                    exp(-0.5*i^2/snakeGradientSigma^2);
      dg = [dgi dg -dgi];
      i = i + 1;
      if dgi > maxval
          maxval = dgi;
      end
end

% Calculate the derivative of a Gaussian in x convolved with snakeImage
sub = 1+floor(length(dg)/2):(1+size(im,2)+length(dg)/2-1);
fi1 = zeros(size(im));
for i=1:size(im,1)
    new = conv(im(i,:),dg);
    fi1(i,:) = new(sub);
end

% Smooth the resulting derivative in y
fi2 = zeros(size(fi1));
sub = 1+floor(length(g)/2):(1+size(fi1,1)+length(g)/2-1);
for i=1:size(fi1,2)
    new = conv(fi1(:,i)',g');
    fi2(:,i) = new(sub)';
end

% Calculate the derivative of a Gaussian in y convolved with snakeImage
fi3 = zeros(size(im));
sub = 1+floor(length(dg)/2):(1+size(im,1)+length(dg)/2-1);
for i=1:size(im,2)
new = conv(im(:,i)',dg');
fi3(:,i) = new(sub)';
end

% Smooth the resulting derivative in x
sub = 1+floor(length(g)/2):(1+size(im,2)+length(g)/2-1);
fi4 = zeros(size(fi3));
for i=1:size(fi3,1)
    new = conv(fi3(i,:),g);
	fi4(i,:) = new(sub);
end
gradient = abs(sqrt(fi2.^2+fi4.^2));
maxg=max(max(gradient));
ming=min(min(gradient));
gradient=(gradient-ming)*255/(maxg-ming);

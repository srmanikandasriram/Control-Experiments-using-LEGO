% Returns the real X (in cm from the middle line) of an object in the
% image of the robots camera
%
% This has been optimized by hand, an automatic method would be 
% nicer (if the angle of the camera is changed this will not work!!!)
%
% It has been optimized using the image
% \matlab_robot\docs\10cm_paper_2x2bricks_in_lines.gif
function px=x_to_prop_x(x,y);
px=12.5*(x-.495)/(y+0.14); 
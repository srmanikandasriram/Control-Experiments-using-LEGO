% Tries to follow the trolley keeping it in the middle
% of the image and 30 cm away from the robot.
%
% The function detect_trolley is used for (surprisingly =] )
% detecting where the trolley is in the picture.
%
% Uses two PD-regulators, one for the speed of the robot
% and one for the angle.
%
% If the robot doesn't see the trolley it will turn left/right
% until it is detected in the picture.
%
% If a time_limit is given, the function will run for that time
% and measure an analyzes per second rate. Otherwise the program
% will run until some key is pressed.
%
% USAGE:      rate=follow_trolley(time_limit)
%
% OR:         follow_trolley
%
% author: Asmo Soinio, asoinio@abo.fi, 7.8.2002
function rate=follow_trolley(time_limit)
global controller g_detect running;

% If the script robot_init hasn't been ran
if (~length(who('global','G_KAB')))
    robot_init
end

% stop the robot
controller.brakeAll;

% the limit to define trolley as detected in the image
% THIS SHOULD PROBABLY BE ALTERED, test your setting with
% [x z s]= detect_trolley(1) with and without
% the trolley in the picture to test for appropriate limit
DETECTED=85;

% The motors seem to drive with different speeds...
SPEED_NORMAL_A=80;
SPEED_NORMAL_B=150;

DISTANCE=30; % The distance to keep to the trolley (cm)
% Find the y-level that gives z=DISTANCE (cm):
DIST_Y=fminsearch(['abs(y_to_z(x)-' num2str(DISTANCE) ')'],.5) 

DIST_EPS=1; % Epsilon for distance (cm)
ANGLE_EPS=2*pi/180; % Angle epsilon (rad)

% derivative gain, angle regulator (0.3, 1.5)
Kd=0.3;
% propotional gain, angle regulator
Kp=1.5;

% derivative gain, speed regulator (0.001)
Kd_s=0.001;
% propotional gain, speed regulator (0.04)
Kp_s=0.04;

% These are used to count the analyzes per second rate
% when this function is used with a timelimit
g_detect=0;
start_time=clock;

% Grab an image and detect the trolley:
[x z s g sz]=detect_trolley;

% initialize the figure and the 'line of sight'
fh=figure(666);
set(fh,'Resize','off','Position',[500 300 sz(2)*1 sz(1)*1],'KeyPressFcn','global running; running=0;');
ih=image(g,'EraseMode','none');
lh=line([sz(2)/2 sz(2)/2],[sz(1) sz(1)*DIST_Y],'Marker','s','Color','red','MarkerSize',10,'EraseMode','none');

% hide the vfm-window, the function will use an own window
vfm('show',0);

% If the trolley is not found in the picture, turn clockwise/anti clockwise...
if(s<DETECTED)
    search_trolley(DETECTED, ih);
end
    
tic;

% initialize some variables
old_angle=0;
old_z=DISTANCE;
toc_old=toc;
last_angle=0;
not_detected=0;
running=1;

% loop until a key is pressed (running==false) or the function has ran for time_limit
while ( (running & nargin==0) | (nargin>0 & etime(clock,start_time)<time_limit) )
    [x z s g sz ox oy]=detect_trolley;
    
    % Draw the black 'aiming' lines to the image:
    g(:,round(sz(2)/2),:)=0;
    g(round(sz(1)*DIST_Y),:,:)=0;    
    
    % Set the new data to the onscreen image
    set(ih,'CData',g);
    
    % if the trolley exists in he image
    if(s>DETECTED)
        angle=0;
        if(z~=0) angle=atan(x/z); end

        % Draw the 'line of sight', coloured red (trolley not in center) or green 
        % (trolley within the epsilon boundaries)
        colour='r';
        if(abs(angle)<ANGLE_EPS & abs(z-DISTANCE)<DIST_EPS) 
            colour='g';
        end
        set(lh,'XData',[sz(2)/2 ox],'YData',[sz(1) oy],'Color',colour);

        % These are used to detect when the robot has totally lost sight of the 
        % trolley and to determin whether to turn left or right to find it again
        last_angle=angle;
        not_detected=0;
        
        % Use the PD-regulators to determin new turning speed and speed
        turn=pd_regulator(Kp, Kd, angle, old_angle, 0, toc_old);
        speed=pd_regulator(Kp_s, Kd_s, z, old_z, DISTANCE, toc_old);

        % old time, angle and z, used by the regulators to determin dt, dangle and dz
        toc_old=toc;
        old_angle=angle;
        old_z=z;
        
        % if nearly right position, set motorspeed to 0
        if(abs(angle)<ANGLE_EPS & abs(z-DISTANCE)<DIST_EPS)
            set_motors(0,0);
        else
            set_motors(SPEED_NORMAL_A*-turn+SPEED_NORMAL_A*-speed,SPEED_NORMAL_B*turn+SPEED_NORMAL_B*-speed);
        end
        
    % if no trolley is found in the image    
    else
        not_detected=not_detected+1;
        
        % if not seen within 5 analyzes, search for the trolley
        if(not_detected>5)
            search_trolley(DETECTED, ih, last_angle<0);
            not_detected=0;
        end
    end
    
    % pause, this will help Matlab to avoid crashing
    pause(0.0005);
end

% When using the system with a time limit
disp('Analyzes / second:');
disp(g_detect/etime(clock,start_time));
controller.brakeAll
rate=g_detect/etime(clock,start_time);

%
%
%
function search_trolley(DETECTED, ih, left)
% Turn left/right until the trolley is detected
%
% ih = handle to the image where the picture from the camera should be shown
%
% If the argument left is not defined, the direction will be random

if nargin==2
	if(rand<.5) turn_right(255)
	else turn_left(255)
	end
else
    if (left) turn_left(255)
    else turn_right(255)
    end
end

s=0;
% ...until the trolley is found
while (s<DETECTED)
    [x z s g]=detect_trolley;
    set(ih,'CData',g);
    % pause, this will help Matlab to avoid crashing
    pause(0.0005);    
end

function turn_right(speed)

global controller;

controller.setAllMotors(speed*.5,robot3.Controller.FORWARD,speed,robot3.Controller.REVERSE,0,0);

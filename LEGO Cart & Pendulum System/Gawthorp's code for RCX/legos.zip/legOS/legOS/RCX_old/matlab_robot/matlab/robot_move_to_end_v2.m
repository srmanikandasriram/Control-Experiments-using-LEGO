% PD-regulator version of robot_move_to_end
%
% Can even follow somewhat trickier lines
% Nice values: Kd=2, Kp=5
function report=robot_move_to_end_v2

global controller index report;

% Limit to detect the end line
END_LINE_LIMIT=50;

SPEED_NORMAL_A=50;
SPEED_NORMAL_B=150;
SPEED_CHANGE_A=50;
SPEED_CHANGE_B=150;

MIDDLE=0.5;

% derivative gain
Kd=1.5;
% propotional gain
Kp=4;

report=[0, 0, 0, 0, 0, 0];
old_x=MIDDLE;

index=1;

controller.brakeAll;
tic;
mx=analyze_hline;

add_report(0,0, mx);
toc_old=toc;

set_motors_fwd(SPEED_NORMAL_A,SPEED_NORMAL_B);

while(mx<END_LINE_LIMIT)
    [x strongness image]=analyze_vline;
    
    u=pd_regulator(Kp, Kd, x, old_x, MIDDLE, toc_old);
    toc_old=toc;
    old_x=x;
    if(strongness>80)
        set_motors_fwd(SPEED_NORMAL_A-SPEED_CHANGE_A*u,SPEED_NORMAL_B+SPEED_CHANGE_B*u);
    end
    
    mx=median_max_ver_der(image, 109, 119);
    add_report(x, strongness, mx);
    pause(0.0005);
end

pause(0.5);
controller.brakeAll;
mx=analyze_hline;
add_report(0,0, mx);


% G_SIZE_ABC=adjust_prop_size
%
% This function adjust the prop_size-function's arguments so that 
% it can correctly convert picture size and y values to propotional
% (not y depended) size values.
%
% The results are stored in the global G_SIZE_ABC-value and also returned
%
% To use this function place the robot to the line on the
% measurement paper (with 5 small black bricks placed on the boxes)
% and make sure the robot is perpendicular to the line. To print the 
% measurement paper print the 
% image \matlab_robot\docs\10cm_paper_2x2bricks.gif with 10 dpi.

function G_SIZE_ABC=adjust_prop_size
global G_SIZE_ABC;

close all;
[objects grab] = analyze_objects(1,1,100);

figure;
image(grab/255);
s=size(grab);
height=s(1);
width=s(2);

if(length(objects)<5)
    error('Less than 5 objects detected!');
end
if(length(objects)>5)
    error('More than 5 objects detected!');
end

clear sz;
for(I=1:length(objects))
    H=line([objects(I).x*width;...
            objects(I).x*width;...
            objects(I).x*width+objects(I).width*width;... 
            objects(I).x*width+objects(I).width*width;...
            objects(I).x*width;...
        ],...
        [objects(I).y*height;...
            objects(I).y*height-objects(I).height*height;...
            objects(I).y*height-objects(I).height*height;...
            objects(I).y*height;...
            objects(I).y*height]);
    set(H,'Color','white');
    H=text(objects(I).x*width,objects(I).y*height+8,[num2str(objects(I).size)]);
    set(H,'Color','red');
    sz(I,1:3)=[objects(I).size objects(I).y objects(I).z ];
end

sz=sortrows(sz,1);
figure;
plot(sz(:,1),sz(:,2),'*-');
xlabel('Size');
ylabel('Y (%)');

[abc, esum, exitflag]=fminsearch(@error_sum,[1 1 1],[],sz)

if(exitflag~=1)
    error('The optimization did not converge!');
end

figure;
plot(prop_size(sz(:,1),sz(:,2),abc),'o-');
legend('function prop\_size(size,y)');

G_SIZE_ABC=abc;

function error=error_sum(abc,sz)
size=prop_size(sz(:,1),sz(:,2),abc);
error=sum((size-1).^2);
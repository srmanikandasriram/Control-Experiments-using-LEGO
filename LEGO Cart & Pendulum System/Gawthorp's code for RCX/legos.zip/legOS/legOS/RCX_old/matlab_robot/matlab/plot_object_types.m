% plots the object database as 2d-plots with the features

global O_TYPE_NAMES;

load object_db.txt;

n=max(object_db(:,1));

plots=['bo';'gx';'r+';'c*';'ms';'yd';'bv';'b^';'g<';'rp';'ch'];

clear k;

figure;
hold on;
for I=2:n
    k=find(object_db(:,1)==I);
    plot(object_db(k,2),object_db(k,3),plots(I,:));
    xlabel('red');
    ylabel('green');
    legend(O_TYPE_NAMES(2:9,:));
end
hold off;

figure;
hold on;
for I=2:n
    k=find(object_db(:,1)==I);
    plot(object_db(k,4),object_db(k,5),plots(I,:));
    xlabel('blue');
    ylabel('wideness');    
    legend(O_TYPE_NAMES(2:9,:));
end
hold off;

figure;
hold on;
for I=2:n
    k=find(object_db(:,1)==I);
    plot(object_db(k,6),object_db(k,5),plots(I,:));
    xlabel('prop\_size');
    ylabel('wideness');    
    legend(O_TYPE_NAMES(2:9,:));
end
hold off;

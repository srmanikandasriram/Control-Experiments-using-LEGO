% Converts a picture Y-value to a Z-value. If the input argument kab
% is not defined the function will use the global G_KAB-value. The agument
% ka should be optimized with running the script ADJUST_Z
%
% z=y_to_z(y,kab)
%
% z=k/(y+b)+a where k=kab(1), a=kab(2) and b=kab(3)
%
% See also ADJUST_Z
%

function z=y_to_z(y,kab);
global G_KAB;

try
    local_kab=kab;
catch
    local_kab=G_KAB;
end

z=local_kab(1)./(y+local_kab(3))+local_kab(2);


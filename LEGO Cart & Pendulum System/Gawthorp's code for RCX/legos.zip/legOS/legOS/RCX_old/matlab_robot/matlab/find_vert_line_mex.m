% FIND_VERT_LINE_MEX = Finds vertical lines in the image between the 
%                  Y-coordinates y_limit and y_limit_2 (those included).
%
% Usage:
% [vert_x max_der]=FIND_VERT_LINE_MEX(I, y_limit, y_limit_2, debug)
%
% The image should be a 2- or 3-dimensionell uint8 array
%
% Returns the X-coordinate for the lines found and the maximum value of
% the horisontal derivative in the image, which can be used to evaluate 
% whether a line actually was found or not. 
%
% The max_deer depends on contrasts in the image, with my webcam in a 
% robot I get:
% max_der<30 => weak line, max_der>60 => strong vertical line
%
% If the image-array has 3 dimensions the function assumes that the 3rd
% dimension includes imagedata for different colours (usually RGB) and
% will return the results separately for each color component.
%
% Example: [x max_der]=FIND_VERT_LINE_MEX(image, 100, 110, 0)
%
%       Finds vertical lines from array image between Y-coordinates
%       100 and 110, doesn't show debugging information
%       Returns 2 vectors, size(x)=[11,images color depth], 
%       size(max)=[images color depth]
% 
function [vert_x, max_der]=find_vert_line(I, y_limit, y_limit_2, debug)

s=size(I);
if(length(s)==3)
    colordepth=s(3);
else 
    colordepth=1;
end

if(debug) 
    disp('counting derivatives'); 
    tic
end
der=hor_der(I,y_limit,y_limit_2);
if(debug) 
    disp('Time for derivative count:');
    disp(toc);
end


if(debug) 
    for RGB=1:colordepth        
        figure;
        image_2d(double(der(:,:,RGB)));
    end
end

vert_x=zeros(y_limit_2-y_limit+1,colordepth);

if(debug) 
    tic;
end

for RGB=1:colordepth
    max_der(RGB)=median(double(max(der(:,:,RGB)')));
end
mx=max(max(der));
if(debug) 
    disp('Time for derivative max and median counts:');
    disp(toc);
    tic;
end
for RGB=1:colordepth
    der(:,:,RGB)=der(:,:,RGB)>uint8(double(mx(RGB))/2);
end

if(debug) 
    disp('Time for derivative threshold:');
    disp(toc);
    for RGB=1:colordepth        
        figure;
        image_2d(double(der(:,:,RGB)));
    end
end

der=double(der);

if(debug) 
    disp('counting weighted sums'); 
    tic
end

for RGB=1:colordepth
    if(debug) disp(RGB);
    end
    for Y=1:y_limit_2-y_limit+1
        sumx=sum(find(der(Y,:,RGB)~=0));
        n=sum(der(Y,:,RGB));
%        n=0;
%        sumx=0;
%        for X=2:s(2)-1
%            sumx=sumx+X*der(Y,X,RGB);
%            n=n+der(Y,X,RGB);
%       end
        if n~=0
            vert_x(Y,RGB)=sumx/n;        
        end
    end
end
if(debug)
    disp('Time for couting the weighted sums:');
    disp(toc);
	x=round(vert_x);
	
	J=double(I);
	
	for RGB=1:colordepth
        J(:,:,1)=double(I(:,:,RGB));
        J(:,:,2)=double(I(:,:,RGB));
        J(:,:,3)=double(I(:,:,RGB));    
        color=zeros(3,1);
        color(RGB)=255;
        for Y=y_limit:y_limit_2
            if (x(Y-y_limit+1,RGB)~=0)
                J(Y,x(Y-y_limit+1,RGB),:)=color;
            end
        end
        figure;
        image(J/255);
	end
end
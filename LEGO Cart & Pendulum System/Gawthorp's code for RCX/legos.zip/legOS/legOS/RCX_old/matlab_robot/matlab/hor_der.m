% The function hor_der counts the horisontal derivatives
% of an image. If the input image has many color-layers,
% the derivative is counted for each of them separately.
%
% ymin and ymax determin the rows from which the derivatives
% are calculated. 
%
% The returning array will be of size [image-width x (ymax-ymin) x color-depth]
%
% USAGE: hd=hor_der(image, ymin, ymax)
%
% The function is a MEX-file for MATLAB, the source code is in the .c-file.
function [E,ctrs]=paramlabel(I);

minlength=50; minarea=50;
nr=0; j=0;
I=double(I);
%next=[1,-(n-1),0,(n-1),-1];
X=sparse([]); Y=X;
[n,m]=size(I); E=zeros(n-1,m-1); 
next=[-1,(n-1),0,-(n-1),1];
I(1,:)=0; I(n,:)=0; I(:,1)=0; I(:,m)=0;
J=zeros(n-1,m-1);

% Matrix over gridpoints is assigned pointer to neighbor 
J=J-(I(1:n-1,1:m-1) & ~I(2:n,1:m-1));
J=J+(~I(1:n-1,2:m) & I(2:n,2:m));
J=J*(n-1);
J=J+(I(2:n,1:m-1) & ~I(2:n,2:m));
J=J-(~I(1:n-1,1:m-1) & I(1:n-1,2:m));

% Contours traversed one by one
t=find(J); 
for i=1:length(t) 
  D=t(i);  d=J(D);   
  if d 
    k=0;  D0=D;    O=0; 
    while ~(D==D0)|(k==0)
      k=k+1;
      O(k)=d;
      D=D+d;
      d=J(D); 
      if d==0
        mod(O(k)+n,n-3);
        d=next(mod(O(k)+n,n-3)); 
      end;  
      J(D)=J(D)-d;
    end;
    O(1)=D0;
    % contur cordinates found for contours longer than minlength
    if k>minlength
      % chaincode 2 coordinatedeltas
      x=O; x(abs(O)>1)=0;
      y=O-x; y=sign(y); 
      y(1)=ceil(O(1)/(n-1)+1);
      x(1)=O(1)-(y(1)-2)*(n-1)+1;
      % Absolute coordinates
      X=cumsum(x);       Y=cumsum(y); 
      a=round((x*Y'-y*X')/2);
      % Only large objects regarded
      if a>minarea 
        j=j+1; nr=nr+1; 
        if nargout>1
          ctrs(nr,1:length(X))=complex(X,Y);
        end;
        % Labeled contures marked on emty image 
        x(1)=X(1)-X(end); 
        y(1)=Y(1)-Y(end); 
        cont=cumsum(O);
        ycont=find(y);
        E(cont(ycont)+(n-1)*(y(ycont)<0))=nr*y(ycont); 
      end;
    end;
  end;
end; 
E=cumsum(E);
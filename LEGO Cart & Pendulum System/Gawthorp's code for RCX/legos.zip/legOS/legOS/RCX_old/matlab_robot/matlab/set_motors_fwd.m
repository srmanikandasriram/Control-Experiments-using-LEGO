% sets the levels for the motors, if the new levels differ from
% the current ones with more than 5
function set_motors_fwd(level_a,level_b)
global controller last_sent_time;

last_sent_time=clock;
if (level_a<0) level_a=0; end
if (level_b<0) level_b=0; end
if (level_a>robot3.Controller.MOTOR_LEVELS) level_a=robot3.Controller.MOTOR_LEVELS; end
if (level_b>robot3.Controller.MOTOR_LEVELS) level_b=robot3.Controller.MOTOR_LEVELS; end

if (abs(level_a-controller.getMotorLevel(0))>5 | abs(level_b-controller.getMotorLevel(1))>5 )
	controller.setAllMotors(level_a,robot3.Controller.FORWARD,...
        level_b,robot3.Controller.FORWARD,0,0);
end
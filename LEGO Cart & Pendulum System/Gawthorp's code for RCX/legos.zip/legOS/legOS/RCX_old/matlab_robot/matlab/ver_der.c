/*=============================================================
 * ver_der.c
 *
 * This is a MEX-file for MATLAB.
 *
 *============================================================*/
#include "mex.h"
#include <math.h>

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
  /* Declare variables. */
  int color_depth, y_limit, y_limit_2, number_of_dims, size, res_size;
  int RGB, X, Y, i;
  unsigned char *pr, *pr2;
  unsigned char  *der, *der2;
  const int *dim_array;
  int res_dim_array[3];

  /* Check for proper number of input and output arguments. */
  if(nrhs != 3) {
    mexErrMsgTxt("Three input arguments required, [image data, y_limit, y_limit_2]");
  }

  /* Check data type of input argument. */
  if(!(mxIsUint8(prhs[0]))) {
    mexErrMsgTxt("Input array must be of type UINT8.");
  }

	y_limit = (int) mxGetScalar(prhs[1]);
	y_limit_2 = (int) mxGetScalar(prhs[2]);

  /* Get the number of dimensions in the input argument. */
  number_of_dims = mxGetNumberOfDimensions(prhs[0]);

	/* Check the dimensions of the input array */
  if(number_of_dims<2 || number_of_dims>3) {
		printf("%d!!! => ",number_of_dims);
    mexErrMsgTxt("Input array must be 2- or 3-dimensionell!");
  }

  /* Get the size of dimensions in the input argument. */
  dim_array = mxGetDimensions(prhs[0]);

	/* Check the Y-limits, if errornous correct and give warning message */
	if(y_limit<2) {
		y_limit=2;
		printf("y_limit<2, setting y_limit=2!!!\n");
	}
	if(y_limit>dim_array[0]-1) {
		y_limit=dim_array[0]-1;
		printf("y_limit>imageheight-1, setting y_limit=imageheight-1!!!\n");
	}
	if(y_limit_2<2) {
		y_limit_2=2;
		printf("y_limit_2<2, setting y_limit_2=2!!!\n");
	}
	if(y_limit_2>dim_array[0]-1) {
		y_limit_2=dim_array[0]-1;
		printf("y_limit_2>imageheight-1, setting y_limit_2=imageheight-1!!!\n");
	}

	for(i=1; i<number_of_dims; i++)
		res_dim_array[i]=dim_array[i];

	/* y-size of result array */
	res_dim_array[0]=y_limit_2-y_limit+1;

	//for(i=0; i<number_of_dims; i++)
	//	printf("res_dim(%d): %d\n",i,res_dim_array[i]);

  /*   Allocate the space for the return argument */
	plhs[0] = mxCreateNumericArray(number_of_dims,res_dim_array,mxUINT8_CLASS,mxREAL);

	/* pointer to the result array */
  der = mxGetPr(plhs[0]);

  /* pointer to the input array */
	pr = mxGetPr(prhs[0]);

	/* color depth, size of 3:rd dimension or 1 */
	if(number_of_dims==3)
		color_depth=dim_array[2];
	else color_depth=1;

	// printf("cd:%i, y:[%i..%i], imagesize:[%ix%i]\n",color_depth,y_limit,y_limit_2,dim_array[0],dim_array[1]);

	/* size of a layer in input image */
	size=dim_array[1]*dim_array[0];

	/* size of a layer in output array */
	res_size=res_dim_array[1]*res_dim_array[0];

	for (RGB=0; RGB<color_depth; RGB++)
	  for (X=0; X<dim_array[1]; X++) {
			der2=der+res_size*RGB+res_dim_array[0]*X;
			pr2=pr+size*RGB+dim_array[0]*X+y_limit-1;
	    for (Y=y_limit-1; Y<y_limit_2; Y++) {
				*der2++=(unsigned char)abs((int)*(pr2-1)-(int)*(pr2+1));
				pr2++;
//				printf("x:%i y:%i\t",X,Y);
			}
		}

}

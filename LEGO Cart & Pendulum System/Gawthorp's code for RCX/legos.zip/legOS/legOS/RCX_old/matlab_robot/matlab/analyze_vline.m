%analyze_vline = Grab an image from the webcam and analyze the x of
%                the vertical line in the bottom of the image.
%
% The result is a number between 0.0 and 1.0 according to the
% x-coordinate of the line found, 0.0=left end, 1.0=right end,
% 0.5=center
%
% The algorithm uses only the red input of the camera, which seems to
% suit the yellow/green tape I am using as my line.
%
% If some argument is given to the function, it will show
% debugging information (numbers and pictures of the middle results).
%
% Author: Asmo Soinio
%
function [line_x, mx, image]=analyze_vline(debug)

J=vfm('grab');
image=J(:,:,1);

s=size(image);

y1=s(1)-10;
y2=s(1);
try
    [x mx]=find_vert_line_mex(image,y1,y2,debug);
catch
    [x mx]=find_vert_line_mex(image,y1,y2,0);    
end
line_x=median(x)/s(2);
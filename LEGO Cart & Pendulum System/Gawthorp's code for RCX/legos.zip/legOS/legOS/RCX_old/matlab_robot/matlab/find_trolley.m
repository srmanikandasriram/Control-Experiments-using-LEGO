[x z s g sz]=detect_trolley;

if(s<65)
    disp('No trolley in the image');
    return;
end

bw=double(g);
bw=.30*bw(:,:,1) + .59*bw(:,:,2) + .11*bw(:,:,3);

edg=calgrad(bw,3);

% edg=detect_edges(uint8(bw));
% limit=mean(mean(edg))*6;
% map=edg>limit;
% edg=map.*edg;

% imagesc(edg);

v=[40 25; 48 24; 56 23; 68 30; 68 50; 55 55; 48 55; 38 48];

close all;
figure;
imagesc(edg);
line([v(:,1);v(1,1)],[v(:,2);v(1,2)],'Marker','.','Color','r','MarkerSize',25,'EraseMode','none')

v=greedy(v,edg);
figure;
imagesc(edg);
line([v(:,1);v(1,1)],[v(:,2);v(1,2)],'Marker','.','Color','r','MarkerSize',25,'EraseMode','none')

z=y_to_z(max(v(:,2))/sz(1))

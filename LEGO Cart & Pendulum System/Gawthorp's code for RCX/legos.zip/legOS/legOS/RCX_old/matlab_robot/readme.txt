This the distribution file of my robot project.

Documentation is found in the file matlab_robot\docs\index.html. A more
browsable version of the same documentation is available online at 



13.8.2002
Asmo Soinio, asoinio@abo.fi, www.abo.fi/~asoinio/
package robot3;

import java.awt.*;
import java.awt.event.*;

/**
* This class implements the window that shows the state of the
* robot. A counter of messages sent is also shown. It can be used
* to check that the robot is receiving all of the messages sent,
* as the robot show the number of received messages.
*/
class ControllerOutputWindow extends Frame implements ActionListener {
	MotorLevelViewer[] motorLevels=new MotorLevelViewer[Controller.MOTORS];
    Label msgCountLabel=new Label("Messages sent: 0000");
	long msgCount=0;

	Button clearCount = new Button("Clear count");

	public ControllerOutputWindow() {
		super("robot2.ControllerOutputWindow");
		this.setLayout(new FlowLayout());
		for(int i=0; i<Controller.MOTORS; i++) {
			motorLevels[i]=new MotorLevelViewer();
			this.add(motorLevels[i]);
		}

		Panel p=new Panel();
		p.setLayout(new GridLayout(2,1));

		p.add(msgCountLabel);

		clearCount.addActionListener(this);
		p.add(clearCount);

		this.add(p);

		this.pack();
	}

	public void setMotorLevel(int motor, int level) {
		motorLevels[motor].setLevel(level);
	}

	public void setMotorState(int motor, int state) {
		motorLevels[motor].setState(state);
	}

	public void increaseMessageCount() {
		msgCount++;
		msgCountLabel.setText("Messages sent: "+Long.toHexString(msgCount));
	}

	public void actionPerformed(ActionEvent e) {
		Object c=e.getSource();

		if(c==clearCount) {
			msgCount=-1;
			increaseMessageCount();
		}
	}
}


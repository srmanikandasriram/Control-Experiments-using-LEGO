package robot3;
/**
* Interface that all classes interested by what is received by the IR tower should implement.
* When an objet is interested by the events, it calls addLNPListener to the LNPManager.
* When it's not longer interested, it calls removeLNPListener to the LNPManager.
* @author Fabien Bergeret (fabien.bergeret@laposte.net)
*/
public interface LNPListener
{
	/**
	* Method called by LNPManager when a new integrity packet is received, provided
	* that the current object has subscribed to the LNPManager.
	* @param buffer the data received
	*/
	public void integrityReceived(byte [] buffer);
	/**
	* Method called by LNPManager when a new addressing packet is received, provided
	* that the current object has subscribed to the LNPManager.
	* @param buffer the data received
	* @param toPort the port to which the data was sent
	* @param fromHost the host that sent the data
	* @param fromPort the port from which the data was sent.
	*/
	public void addressingReceived(byte [] buffer, byte toPort, byte fromHost, byte fromPort);
	/**
	* Method called by LNPManager when a packet with a wrong checksum is received, provided
	* that the current object has subscribed to the LNPManager.
	*/
	public void wrongChecksumReceived();
}
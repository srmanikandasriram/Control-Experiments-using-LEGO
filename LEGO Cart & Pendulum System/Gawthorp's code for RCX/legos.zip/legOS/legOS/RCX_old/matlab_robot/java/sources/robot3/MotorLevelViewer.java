package robot3;

import java.awt.*;

/**
* Shows the level of a motor
*/
class MotorLevelViewer extends Panel {
	static final int X_SIZE=30, TEXT_HEIGHT=20;
	static final Dimension PANEL_SIZE=new Dimension(X_SIZE,100);
	static final Color OFF=Color.black;
	static final Color[] STATE_COLOR={Color.lightGray, Color.green, Color.red, Color.cyan};

	int level, y, state=Controller.FLOAT;

	public MotorLevelViewer() {
		setBackground(OFF);
		setSize(PANEL_SIZE);
		setLevel(0);
	}

	public void setState(int state) {
		this.state=state;
		repaint();
	}

	public void setLevel(int level) {
		this.level=level;
		y=(getSize().height-TEXT_HEIGHT)-((getSize().height-TEXT_HEIGHT)*level)/Controller.MOTOR_LEVELS;
		repaint();
	}

	public Dimension getPreferredSize() {
		return(PANEL_SIZE);
	}

	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(STATE_COLOR[state]);
		g.fillRect(0,y,getSize().width,getSize().height-y);
		g.setColor(OFF);
		g.fillRect(0,getSize().height-TEXT_HEIGHT+1,getSize().width,1);
		g.setColor(OFF);
		g.drawString(""+level,3,getSize().height-3);
	}
}
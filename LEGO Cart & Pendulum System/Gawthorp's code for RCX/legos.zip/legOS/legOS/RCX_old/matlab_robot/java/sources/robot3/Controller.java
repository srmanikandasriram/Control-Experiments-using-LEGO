package robot3;

import java.io.*;
import java.awt.*;

/**
*<P>
* This is the main class used to control the robot.
* This is my third version after some trial and error -testing. :) My
* first version based on the robot replying to the messages, but I realized
* that because I'm going to have the IR-tower on the robot there's no need
* for the robot to send anything, as communication is as good as 100%
* and the robots replies will only disturb the PCs sendings.
*<P>
* The JavaLNP interface by Fabien Bergeret (fabien.bergeret@laposte.net)
* is used for communicating with the robot via IR-Tower.
*<P>
* I compiled it (so that Matlab can use it) with the following commandline:<BR>
*<BR>
* javac -g -target 1.1 -d C:\asoinio\java\classes -sourcepath C:\asoinio\java\sources\ *.java<BR>
*<P>
* ---------------<BR>
*<BR>
* These messages are also used by the RCX program robot3.c<BR>
* --<BR>
*<BR>
* Messages, PC => RCX:<BR>
* --<BR>
* R = reset, motor powers to 0 and motors to float<BR>
* S = stop (brake, full voltage to motors)<BR>
*<BR>
* Mxaybzc = Set motor state and speed, x=speed for A, a=state for A,<BR>
*			 y=speed for B, b=state for B...<BR>
*<BR>
* Ax = set motor A's power to the value of x (binary, 0..255)<BR>
* Bx = set motor B's power to the value of x (binary)<BR>
* Cx = set motor C's power to the value of x (binary)<BR>
*<BR>
* 1x = set motor A state to x, (0=off (float), 1=forward, 2=reverse, 3=brake;<BR>
*       defined in robot2.Controller.[FLOAT|FORWARD|REVERSE|BRAKE] )<BR>
* 2x = set motor B state to x<BR>
* 3x = set motor C state to x<BR>
*<P>
* -----------------------------------------------------------------------------<BR>
*<BR>
* When the bumper (SENSOR_2) hits something, the robot will also stop (brake).<BR>
*
* @author Asmo Soinio (asoinio@abo.fi)
*/
class Controller {
	public static boolean DEBUG=false;

	public static final int MOTOR_LEVELS=255;
	public static final int MOTORS=2;
	public static final int FLOAT=0, FORWARD=1, REVERSE=2, BRAKE=3;
	static final String[] STATE_NAMES={"Float","Forward","Reverse","Brake"};
	static final int STATES = STATE_NAMES.length;

	ControllerOutputWindow outputWindow=null;
	ControllerInputWindow inputWindow=null;

	LNPManager manager;

	int[] motorLevel=new int[MOTORS];
	int[] motorState=new int[MOTORS];

	public Controller(boolean interActive) {
		System.out.println("Creating a new robot3 Controller...");

		outputWindow=new ControllerOutputWindow();
		outputWindow.pack();
		outputWindow.setVisible(true);

		manager = LNPManager.getInstance("COM1");

		for(int i=0; i<MOTORS; i++) {
			motorLevel[i]=0;
			motorState[i]=FLOAT;
		}
		if(interActive) inputWindow=new ControllerInputWindow(this);

		System.out.println("...done!");
	}

	public void hide() {
		outputWindow.setVisible(false);
		if(inputWindow!=null) inputWindow.setVisible(false);
	}

	public void show() {
		outputWindow.setVisible(true);
		if(inputWindow!=null) inputWindow.setVisible(true);
	}

	public void setDebug(boolean debug) {
		DEBUG=debug;
	}

	public int getMotorLevel(int motor) {
		return(motorLevel[motor]);
	}

	public int getMotorState(int motor) {
		return(motorState[motor]);
	}

	public boolean isBraking() {
		for(int i=0; i<MOTORS; i++)
			if(motorState[i]!=BRAKE) return(false);

		return(true);
	}

	public void brakeAll() {
		brakeAllNoSend();

		byte[] msg=new byte[1];
		msg[0]=(byte)('S');

		if(DEBUG)System.out.println("Stopping the robot");
		manager.integrityWrite(msg);
		outputWindow.increaseMessageCount();
	}

	public void brakeAllNoSend() {
		for(int i=0; i<MOTORS; i++) {
			outputWindow.setMotorLevel(i, MOTOR_LEVELS);
			motorLevel[i]=MOTOR_LEVELS;
			outputWindow.setMotorState(i, BRAKE);
			motorState[i]=BRAKE;
		}
	}

	public void setAllMotors(int levelA, int stateA, int levelB, int stateB, int levelC, int stateC) {
		if(stateA<0 || stateA>STATES || stateA<0 || stateA>STATES || stateA<0 || stateA>STATES) {
			System.out.println("robot2.Controller.setAllMotors: some state is not between 0 and "
				+STATES+"!!! Not sending the message to RCX!!! States (A,B,C):" + stateA + ", "
				+ stateB + ", " + stateC);
			return;
		}

		outputWindow.setMotorState(0, stateA);
		outputWindow.setMotorLevel(0, levelA);
		motorState[0]=stateA;
		motorLevel[0]=levelA;
		if(MOTORS>1) {
			outputWindow.setMotorState(1, stateB);
			outputWindow.setMotorLevel(1, levelB);
			motorState[1]=stateB;
			motorLevel[1]=levelB;
		}
		if(MOTORS>2) {
			outputWindow.setMotorState(2, stateC);
			outputWindow.setMotorLevel(2, levelC);
			motorState[2]=stateC;
			motorLevel[2]=levelC;
		}
		byte[] msg=new byte[7];
		msg[0]='M';
		msg[1]=(byte)levelA;
		msg[2]=(byte)stateA;
		msg[3]=(byte)levelB;
		msg[4]=(byte)stateB;
		msg[5]=(byte)levelC;
		msg[6]=(byte)stateC;

		if(DEBUG)System.out.println("Setting all motors: (level, state) A:" +
			levelA +"," + STATE_NAMES[stateA] + " B:"+ levelB +"," + STATE_NAMES[stateB] +
			" C:"+ levelC +"," + STATE_NAMES[stateC]);

		manager.integrityWrite(msg);
		outputWindow.increaseMessageCount();
	}

	public void setMotorState(int motor, int state) {
		outputWindow.setMotorState(motor, state);
		motorState[motor]=state;

		byte[] msg=new byte[2];
		msg[0]=(byte)('1'+motor);
		msg[1]=(byte)state;

		if(DEBUG)System.out.println("Setting motor "+ motor +"'s state to " + STATE_NAMES[state]);
		manager.integrityWrite(msg);
		outputWindow.increaseMessageCount();
	}

	public void setMotorLevel(int motor, int level) {
		outputWindow.setMotorLevel(motor, level);
		motorLevel[motor]=level;

		byte[] msg=new byte[2];
		msg[0]=(byte)('A'+motor);
		msg[1]=(byte)level;

		if(DEBUG)System.out.println("Setting motor "+ motor +"'s level to " + level);
		manager.integrityWrite(msg);
		outputWindow.increaseMessageCount();
	}

	public void increaseMotorLevel(int motor, boolean allowReverse) {
		if(motorLevel[motor]<MOTOR_LEVELS-1) {
			motorLevel[motor]++;
			setMotorLevel(motor,motorLevel[motor]);
		}
	}

	public void decreaseMotorLevel(int motor, boolean allowReverse) {
		if(motorLevel[motor]>0) {
			motorLevel[motor]--;
			setMotorLevel(motor,motorLevel[motor]);
		}
	}

	protected int getInputWindowX() {
		return(outputWindow.getSize().width);
	}

	public static void main(String[] args){
		Controller c=new Controller(true);
		c.setDebug(true);
	}

}
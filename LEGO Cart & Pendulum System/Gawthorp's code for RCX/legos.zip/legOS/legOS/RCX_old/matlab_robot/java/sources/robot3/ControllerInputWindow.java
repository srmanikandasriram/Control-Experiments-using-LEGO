package robot3;

import java.awt.*;
import java.awt.event.*;

/**
* This class implements the window used for user to input control
* messages directly to the robot.
*/
class ControllerInputWindow extends Frame implements KeyListener, ActionListener{
	static final char[] PLUS_BUTTONS={'q','w','e','r','t','y','u'};
	static final char[] MINUS_BUTTONS={'a','s','d','f','g','h','j'};

	Controller controller;
	Button[] plusButtons=new Button[Controller.MOTORS];
	Button[] minusButtons=new Button[Controller.MOTORS];
	Button[][] stateButtons=new Button[Controller.MOTORS][4];
	Button[] onOffButtons=new Button[Controller.MOTORS];

	Button brakeAll = new Button("Brake All");

	TextField[] valueInput=new TextField[2*Controller.MOTORS];
	Button setValues = new Button("Set Values");

	public ControllerInputWindow(Controller c) {
		super("robot2.ControllerInputWindow");
		this.controller=c;

		Panel buttonPanel = new Panel();
		buttonPanel.setLayout(new GridLayout(8,Controller.MOTORS));

		for(int i=0; i<Controller.MOTORS; i++)
			buttonPanel.add(new Label("Motor "+(char)('A'+i)));

		for(int i=0; i<Controller.MOTORS; i++) {
			plusButtons[i]=new Button("+ ("+PLUS_BUTTONS[i]+")");
			plusButtons[i].addActionListener(this);
			buttonPanel.add(plusButtons[i]);
			plusButtons[i].addKeyListener(this);
		}

		for(int i=0; i<Controller.MOTORS; i++) {
			minusButtons[i]=new Button("- ("+MINUS_BUTTONS[i]+")");
			minusButtons[i].addActionListener(this);
			buttonPanel.add(minusButtons[i]);
			minusButtons[i].addKeyListener(this);
		}

		for(int j=0; j<4; j++) {
			for(int i=0; i<Controller.MOTORS; i++) {
				stateButtons[i][j]=new Button(Controller.STATE_NAMES[j]);
				stateButtons[i][j].addActionListener(this);
				buttonPanel.add(stateButtons[i][j]);
				stateButtons[i][j].addKeyListener(this);
			}
		}
		for(int i=0; i<Controller.MOTORS; i++) {
			onOffButtons[i]=new Button("(On/Off)");
			onOffButtons[i].addActionListener(this);
			buttonPanel.add(onOffButtons[i]);
			onOffButtons[i].addKeyListener(this);
		}
		this.add(buttonPanel,BorderLayout.WEST);

		this.add(new Label("   "),BorderLayout.CENTER);

		Panel valuePanel = new Panel();
		valuePanel.setLayout(new GridLayout(8,Controller.MOTORS));

		for(int i=0; i<Controller.MOTORS; i++)
			valuePanel.add(new Label("Motor "+(char)('A'+i)+" level/state"));

		for(int i=0; i<Controller.MOTORS; i++) {
			valueInput[2*i]=new TextField("0");
			valuePanel.add(valueInput[2*i]);
			valueInput[2*i].addKeyListener(this);
		}
		for(int i=0; i<Controller.MOTORS; i++) {
			valueInput[2*i+1]=new TextField("0");
			valuePanel.add(valueInput[2*i+1]);
			valueInput[2*i+1].addKeyListener(this);
		}

		setValues.addActionListener(this);
		setValues.addKeyListener(this);
		valuePanel.add(setValues);
		for(int i=0; i<(Controller.MOTORS*5-1); i++) valuePanel.add(new Canvas());

		this.add(valuePanel,BorderLayout.EAST);

		brakeAll.addActionListener(this);
		brakeAll.addKeyListener(this);
		this.add(brakeAll,BorderLayout.SOUTH);

		addKeyListener(this);
		if (c!=null) this.setLocation(c.getInputWindowX(),0);

		this.setVisible(true);
		this.pack();
		this.requestFocus();
	}

	private void adjustSpeed(int input, boolean plus) {
		if(plus) controller.increaseMotorLevel(input, true);
		else controller.decreaseMotorLevel(input, true);
	}

	private void motorOnOff(int motor) {
		if(controller.getMotorLevel(motor)==0)
			controller.setMotorLevel(motor, Controller.MOTOR_LEVELS);
		else
			controller.setMotorLevel(motor, 0);
	}

	public void actionPerformed(ActionEvent e) {
		Object c=e.getSource();

		if(c==brakeAll) controller.brakeAll();
		else if(c==setValues) {
			int levelA=0, stateA=0, levelB=0, stateB=0, levelC=0, stateC=0;
			levelA=Integer.parseInt(valueInput[0].getText());
			stateA=Integer.parseInt(valueInput[1].getText());
			if(Controller.MOTORS>1) {
				levelB=Integer.parseInt(valueInput[2].getText());
				stateB=Integer.parseInt(valueInput[3].getText());
			}
			if(Controller.MOTORS>2) {
				levelC=Integer.parseInt(valueInput[4].getText());
				stateC=Integer.parseInt(valueInput[5].getText());
			}
			controller.setAllMotors(levelA, stateA, levelB, stateB,levelC, stateC);
		}
		else {
			for(int i=0; i<Controller.MOTORS; i++) {
				if(c==plusButtons[i]) adjustSpeed(i,true);
				if(c==minusButtons[i]) adjustSpeed(i,false);
				for(int j=0; j<4; j++) {
					if(c==stateButtons[i][j]) controller.setMotorState(i,j);
				}
				if(c==onOffButtons[i]) motorOnOff(i);
			}
		}
	}

	public void keyTyped(KeyEvent e) { }
	public void keyPressed(KeyEvent e) {
		char c=e.getKeyChar();
		for(int i=0; i<Controller.MOTORS; i++) {
			if(c==PLUS_BUTTONS[i]) adjustSpeed(i,true);
			if(c==MINUS_BUTTONS[i]) adjustSpeed(i,false);
		}
	}
	public void keyReleased(KeyEvent e) { }
}
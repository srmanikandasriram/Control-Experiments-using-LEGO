/* 	$Id: lnptest_pc.c,v 1.2 2002/04/11 08:32:05 peterg Exp $ */
/* 	$Log: lnptest_pc.c,v $ */


/* lnptest_pc.c */
/* Simple network test */

#include "../../lnpd+liblnp/liblnp/liblnp.h"

int main(int argc, char **argv) 
{
  char *r2p, *r2r, *p2r, *p2p;
  int result;

  r2p = "r2p";			/* RCX to PC string */
  r2r = "r2r";			/* RCX to RCX string */
  p2r = "p2r";			/* PC to RCX string */
  p2p = "p2p";			/* PC to PC string */


  printf("start\n");		/* Show start */

  if(lnp_init(0,0,0,0,0))	/* Initialise lnp */
{
  printf("lnp_init error\n");
 }
else
  printf("init OK\n");
	  


  sleep(1);
  printf("%s\n",p2p);		/* Show p2p */
  sleep(1);
  printf("end\n");		/* Show end */

  return 0;
}

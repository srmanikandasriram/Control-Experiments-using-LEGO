/* Parameters for cart.c */
/* Should correspond to vcLegoCart_numpar.txt */

#define k_v   5.0
#define DEADBAND 0.1

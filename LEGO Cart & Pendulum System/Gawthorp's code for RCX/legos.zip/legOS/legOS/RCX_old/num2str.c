/* Ascii */
#define NUL 0
#define ZERO 48
#define PLUS 43
#define MINUS 45
#define DOT 46
#define E 101 
#define SPACE 32

/* Significant figs */
#define SF 6

void num2str(char s[], double X[], int N)
{
  
  /*   ## Test function to convert real to a string */

  /*   N = length(X); */
  
  int count=0;			/* String counter  */
  int i, i_number, i_n, exponent, digits;
  double x,ax,mantissa,n,tenexp;
  char c;
  
  for (i_number=0;i_number<N;i_number++)
    {	
      x = X[i_number];
      
      /* Get exponent */
      if (x>0)
	ax=x;
      else 
	ax=-x;
      
      if (ax>=1)
	{
	  exponent = 0;
	  while (ax>=1)
	    {
	      exponent++;
	      ax = ax/10;
	    };
	}
      else
	exponent = 0;
      if (ax!=0)
	{
	  while (ax<1)
	    {
	      exponent--;
	      ax = ax*10;
	    }
	}
      
      
      /*     ## Compute mantissa */
      tenexp = 1;
      if (exponent>0)
	for (i=0;i<exponent;i++) tenexp=tenexp*10;
      else if (exponent<0)
	for (i=0;i<-exponent;i++) tenexp=tenexp/10;
      
      mantissa = x/tenexp;
      
      /*   ## Signs */
      if (mantissa>0)
	s[count++] = PLUS;
      else 
	if (mantissa<0)
	  s[count++] = MINUS;
      
      /*     ## Mantissa string */
      /*   n = abs(mantissa);     */
      if (mantissa>0)
	n = mantissa;
      else
	n = -mantissa;
      
      for (i=0;i<SF;i++)
	{
	  i_n = n;
	  c = i_n + ZERO;
	  s[count++] = c;
	  if (i==0)
	    s[count++] = DOT;
	  n = (n-i_n)*10;
	}
      
      /*     ## Exponent string */
      s[count++] = E;
      
      /*   ## Sign */
      if (exponent>0)
	s[count++] = PLUS;
      else if (exponent<0)
	s[count++] = MINUS;
      else
	s[count++] = ZERO;
      
      
      /*   n = abs(exponent);     */
      if (exponent>0)
	n = exponent;
      else
	n = -exponent;
      
      digits=0;
      while (n>=1)
	{
	  digits++;
	  n = n/10;
	}
      
      /*     ## Create exponent string */
      for (i=0;i<digits;i++)
	{
	  n = n*10;
	  i_n = n;
	  c = i_n + ZERO;
	  s[count++] = c;
	  n = n-i_n;
	}
      
      if (i_number<N-1)
	s[count++] = SPACE;
      else
	s[count++] = NUL;
    }
};

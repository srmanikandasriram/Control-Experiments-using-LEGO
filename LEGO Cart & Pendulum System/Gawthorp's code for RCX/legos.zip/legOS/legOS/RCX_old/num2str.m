function s = num2str (X)

  ## usage:  s = num2str (x)
  ##
  ## Test function to convert real to a string

  N = length(X);

  ZERO = 48;			# Ascii zero
  SF=6;				# significant figs
  count=0;			# String counter

  for i_number=1:N
    x = X(i_number);

    ## Get exponent
    ax = abs(x);
    if (ax>=1)
      exponent = -1;
      while (ax>=1)
	exponent++;
	ax = ax/10;
      endwhile
    else
      exponent = 0;
      if (ax!=0)
	while (ax<1)
	  exponent--;
	  ax = ax*10;
	endwhile
      endif
    endif
    
    ## Compute mantissa
    mantissa = x/10^exponent;

    ## Signs
    if (mantissa>0)
      s(1,++count) = "+";
    elseif (mantissa<0);
      s(1,++count) = "-";
    endif

    ## Mantissa string
    n = abs(mantissa);
    for i=1:SF
      i_n = floor(n);
      c = i_n + ZERO;
      s(1,++count) = c;
      if (i==1)
	s(1,++count) = ".";
      endif
      n = (n-i_n)*10;
    endfor

    ## Exponent string
    s(1,++count) = "e";

    ## Sign
    if (exponent>0)
      s(1,++count) = "+";
    elseif (exponent<0)
      s(1,++count) = "-";
    else
      s(1,++count) = "0";
    endif
    
    n = abs(exponent);
    digits=0;
    while (n>=1)
      digits++;
      n = n/10;
    endwhile
    
    ## Create exponent string
    for i=1:digits
      n = n*10;
      i_n = floor(n);
      c = i_n + ZERO;
      s(1,++count) = c;
      n = n-i_n;
    endfor

    if i_number<N
      s(1,++count) = " ";
    endif
    
  endfor

  s = setstr(s);		# Integer --> string
endfunction

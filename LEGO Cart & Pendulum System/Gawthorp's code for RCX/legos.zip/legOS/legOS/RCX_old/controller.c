double controller(double y, double w, double state[N_state])
{
  double u;
  double k=2.5;

  u = k*(w-y);

  return u;
}

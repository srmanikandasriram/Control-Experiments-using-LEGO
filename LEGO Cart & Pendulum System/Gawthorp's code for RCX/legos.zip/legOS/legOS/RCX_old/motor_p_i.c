/* 	$Id: motor_p_i.c,v 1.2 2002/01/23 14:36:43 peterg Exp $	 */
/* 	$Log: motor_p_i.c,v $
 * 	Revision 1.2  2002/01/23 14:36:43  peterg
 * 	The first (integer) version of the prop-control programme
 *	 */

/* motor_p_i.c */
/* Prop control using integers */

#include <unistd.h>
#include <dmotor.h>
#include <conio.h>
#include <dsensor.h>

int main(int argc, char **argv) 
{

  int k,kk;
  int u = 0;
  int w = 100;
  int y;
  int error = 0;
  int gain = 10;
  int last = 20; /* sec */
  int dt = 50; /* msec */
  int period = 5; /* sec */

  /* turn sensor on */
  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  /* calibrate sensor to 0 */
  ds_rotation_set(&SENSOR_1,0);
  msleep(100);



  /* Main loop */
  kk = 0;
  for(k=0;k<(last*1000)/dt;k++)
    {

      /* Square setpoint */
      kk++;
      if (kk>(1000*period)/dt) {
	kk = 0;
	w = -w;
      };
	     
      msleep(dt); /* Hang about */

      y = -ROTATION_1;
      error = w - y;

      u = gain*error; 

      if (u>MAX_SPEED) u = MAX_SPEED; 
      if (u<-MAX_SPEED) u = -MAX_SPEED; 

      if (u>0)
	motor_a_dir(fwd);
      else
	{
	  motor_a_dir(rev);
	  u = -u;
	};
	  
      motor_a_speed(u);

      /* Display rotation */
      lcd_int(y);
    }

  motor_a_dir(off);
  return 0;
}






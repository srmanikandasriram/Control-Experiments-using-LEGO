/* 	$Id: cart.c,v 1.11 2002/10/25 06:45:19 peterg Exp peterg $ */
/* 	$Log: cart.c,v $
 * 	Revision 1.11  2002/10/25 06:45:19  peterg
 * 	Added "STEPFACTOR" for more accurate computation of u*
 *
 * 	Revision 1.10  2002/10/23 23:56:36  peterg
 * 	Rebuilt cart - cahnge sign of angle sensor
 *
 * 	Revision 1.9  2002/10/23 22:39:53  peterg
 * 	Fixed bug in laguerre
 * 	a_u = 2
 *
 * 	Revision 1.8  2002/10/23 04:24:39  peterg
 * 	*** empty log message ***
 *
 * 	Revision 1.7  2002/10/01 14:08:46  peterg
 * 	Now gets U from laptop via IR
 *
 * 	Revision 1.6  2002/10/01 11:21:04  peterg
 * 	Don't send time
 *
 * 	Revision 1.5  2002/10/01 10:52:00  peterg
 * 	Don't rerurn time.
 *
 * 	Revision 1.4  2002/09/24 13:54:28  peterg
 * 	Changed gain/setpoint for nicer results
 *
 * 	Revision 1.3  2002/09/16 11:29:41  peterg
 * 	Removed debugging stuff
 *
 * 	Revision 1.2  2002/09/16 11:28:46  peterg
 * 	Sends ints to IR tower
 * 	Generated ustar
 *
 * 	Revision 1.1  2002/09/14 15:54:38  peterg
 * 	Initial revision
 *
 * 	Revision 1.1  2002/09/09 14:42:08  peterg
 * 	Initial revision
 *
 * 	Revision 1.4  2002/04/05 10:52:17  peterg
 * 	Revised for new RS potentiomenter
 *
 * 	Revision 1.3  2002/02/04 21:12:18  peterg
 * 	Prop. control of position
 *
 * 	Revision 1.2  2002/02/01 15:09:45  peterg
 * 	Added pendulum angle sensor
 * 	Added time loop
 *
 * 	Revision 1.1  2002/01/26 14:34:33  peterg
 * 	Initial revision
 * */


/* cart.c */
/* Open-loop cart */

/* Use integers - comment out to use strings */
#define USE_INTEGERS 1

#include <lnp.h>
#include <unistd.h>
#include <dmotor.h>
#include <conio.h>
#include <dsensor.h>
#include <string.h>
#include <time.h>

/* Ascii */
#define NUL 0
#define ZERO 48
#define PLUS 43
#define MINUS 45
#define DOT 46
#define E 101 
#define SPACE 32

/* String buffer */
#define LEN 100

/* Angle sensor data  */
#define MAX_INT_ANGLE 1023
#define MAX_ANGLE   3.142
#define INTERNAL_RESISTANCE 10000
#define POT_RESISTANCE 20000

#define TICKS_PER_METRE 72.0
#define e_0  (2.0/TICKS_PER_METRE)
#define PI 3.124
#define LENGTH 0.16		/* metre */


#define GAIN 5.0
#define N_T 10
#define N_U 4
#define a_u 4.0
#define DT 0.11
#define STEPFACTOR 2
#define W 1.0			/* m */
#define I2R 1000.0

/* Define the function num2str */
/* #include "num2str.c" */

/* Declare U and ustar */
double U[N_U],     U_new[N_U];
double ustar[N_U], ustar_old[N_U];
double Ustar[N_U][N_T];

int i_U=0;

int new_U=0;

void initialise_sensors()
{
  /* Pendulum angle sensor */
  ds_passive(&SENSOR_2);

  /* Left sensor on */
  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  /* Calibrate left sensor to 0 */
  ds_rotation_set(&SENSOR_1,0);

  /* Right sensor on */
  ds_active(&SENSOR_3);
  ds_rotation_on(&SENSOR_3);

  /* Calibrate right sensor to 0 */
  ds_rotation_set(&SENSOR_3,0);
}

double pendulum_angle(double angle_0)
{
  double angle,resistance;
  unsigned int angle_raw;
  angle_raw = SENSOR_2/64;
  resistance = 1.0*angle_raw*INTERNAL_RESISTANCE/(MAX_INT_ANGLE-angle_raw); /* ohms */
  angle = -2*PI*(resistance/POT_RESISTANCE);	/* Radians */
  return angle-angle_0;
} 

double cart_position()
{
  double position_raw, position;
  int position_raw_left, position_raw_right;
  position_raw_left = ROTATION_1;
  position_raw_right = ROTATION_3;
  position_raw = position_raw_left/2.0 + position_raw_right/2.0;
  position = position_raw/TICKS_PER_METRE;	/* metre */
  return position;
} 

double sin(double theta)	/* Needs replacing with proper sin */
{
  return theta;			/* Small angle approx */
}
double load_position(double angle_0)
{
  double pendulum_position,angle;

  angle = pendulum_angle(angle_0);
  pendulum_position = LENGTH*sin(angle);
  return pendulum_position+cart_position();
} 

double drive(double u)
{

  int u_int;

  /* Clip control to +- 1 */
  if (u>1) u = 1; 
  if (u<-1) u = -1; 
  
  if (u>0) {
    motor_a_dir(fwd);
    motor_c_dir(fwd);
    u_int = u*MAX_SPEED;
  }
  else
    {
      motor_a_dir(rev);
      motor_c_dir(rev);
      u_int = -u*MAX_SPEED;
    };
  
  motor_a_speed(u_int);		/* Motor speed */
  motor_c_speed(u_int);		/* Motor speed */

  return u;			/* Actual control */
} 

double laguerre(double a, int i, int j)
{
/* Generates the ij coeff of the laguerre matrix*/
  if (i<j) return 0.0;
  else
    {
      if (i==j) return -a;
      else return -2*a;
    }
}

void generate_ustar(double new[N_U], double old[N_U] , double a, double dt)
{
/* Generates u* using laguerre basis fun*/
  double dxdt;
  int i,j;

  /* Laguerre part */
  for (i=0;i<N_U;i++)
    {
      dxdt = 0.0;
      for (j=0;j<N_U;j++)
	dxdt = dxdt + laguerre(a,i,j)*old[j];
      new[i] = new[i] + dxdt*dt;
    }

  for (i=0;i<N_U;i++) old[i] = new[i]; /* Save */

}

void initialise_ustar(double ustar[N_U])
{
  int i;
  for (i=0;i<N_U;i++)
    ustar[i] = 1.0;
}

void initialise_u(double U[N_U])
{
  int i;
  for (i=0;i<N_U;i++)
    U[i] = 0.0;
}

#ifdef USE_INTEGERS
#include "putint.c"
void put_data(double position, double angle, double u)
{
  int N=3;
  int I[N];

  I[0] = position*I2R;
  I[1] = angle*I2R;
  I[2] = u*I2R;

  putint(I,N);
  
};
#else
void put_data(double time, double position, double angle, double u)
{
  int N=4;
  double X[N];
  unsigned char data[LEN];

  X[0] = time;
  X[1] = position;
  X[2] = angle;
  X[3] = u;

  num2str(data,X,N);
  lnp_integrity_write(data,strlen(data)+1);
  
};
#endif

void get_U(const unsigned char *data, unsigned char len)
/* Gets the U vector from laptop via IR */
{
  int i,I;
  char c[2];

/* Get U */
  for (i=0;i<N_U;i++)
    {
      c[0] = data[2*i];
      c[1] = data[2*i+1];
      memcpy(&I,&c,2);
      U_new[i] = I/I2R;
    };
  new_U = 1;
};

void precompute_ustar()
     /* Precomputes U* */
{
  int i,j,k;
  
  for (i=0;i<N_T;i++)
    {
      lcd_int(i);

      for (j=0;j<STEPFACTOR;j++)
	generate_ustar(ustar, ustar_old , a_u, DT/STEPFACTOR);

      for (k=0;k<N_U;k++)
	Ustar[k][i] = ustar[k];
    };
  
};

int main(int argc, char **argv) 
{

  int i,iu,i_position;

  double kk;
  double angle, angle_0, position;
  double w = 0.0;		/* metre */
  double y, u ,e, u_out;

  double t=0.0;
  sleep(1);

  /* Initialise */
  initialise_sensors();
  initialise_ustar(ustar_old);
  initialise_ustar(ustar);
  initialise_u(U);
  initialise_u(U_new);
/*   precompute_ustar(); */

  msleep(1000);
  cputs("SET");
  /* Setup lnp from laptop */
  lnp_integrity_set_handler(get_U);
/*   lcd_clear(); */

  msleep(1000);
  cputs("START");
  msleep(1000);

  /* Main loop */
  kk = 0;
  angle_0 = pendulum_angle(0.0);
 
  while(1)
    { 
/*       angle = pendulum_angle(angle_0); */
/*       position = cart_position(); */
/*       y = position; */
/*       e = w-y; */

/*       /\* P + Dead zone *\/ */
/*       if ((e<e_0)&&(e>-e_0)) */
/* 	u = 0; */
/*       else */
/* 	u = GAIN*e; */

/*       if (new_U==1) */
/* 	{ */
/* 	  for (i=0;i<N_U;i++) */
/* 	    U[i] = U_new[i];	/\* Change U here *\/ */
/* 	  i_U = 0; */
/* 	  new_U = 0; */
/* 	  /\* Reinitialise ustar *\/ */
/* 	  initialise_ustar(ustar); */
/* 	  initialise_ustar(ustar_old); */
/* 	}; */

      u=0;
/*       for (i=0;i<N_U;i++) */
/* 	{ */
/* 	  u = u + U[i]*Ustar[i][i_U]; */
/* 	}; */

      msleep(1000);
      lcd_int(i_U);
      if (i_U<N_T-1)
	i_U++;

/*       iu = u*I2R; */
/*       i_position = position*I2R; */

/*       u_out = drive(u); */
/*       put_data(position,angle,u_out); */
/* /\*       /\\*       put_data(ustar[0], ustar[1], ustar[2]); *\\/ *\/ */

/*       t = t+DT; */
      return 0;
    }
}

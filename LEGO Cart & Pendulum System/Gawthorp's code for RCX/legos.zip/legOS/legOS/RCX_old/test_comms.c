/* test_coms.c
   Based on robot3.c at http://www.abo.fi/fak/ktf/rt/robot/ 
   PJG Sep 2002
*/

#include <conio.h>
#include <unistd.h>
#include <string.h>
#include <lnp.h>
#include <dmotor.h>
#include <dsensor.h>
#include <time.h>

unsigned long m_index=0;
unsigned long i_index=0;

void my_handler(const unsigned char *data, unsigned char len)
{
  cputs("MESS");
  m_index++;
}

int main()
{
  lnp_integrity_set_handler(my_handler);

  cputs("WAIT");

  while(1)
    {
      i_index++;
      msleep(1000);
      cputw(i_index);
      msleep(1000);
      cputw(m_index);
    }

  cputs("DONE");
  return 0;
}

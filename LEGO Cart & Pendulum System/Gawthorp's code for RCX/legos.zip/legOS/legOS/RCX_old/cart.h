/* Declare U and ustar */
#include "Ustar.h"

/* Declare parameters */
#include "numpar.h"

#include <lnp.h>
#include <unistd.h>
#include <dmotor.h>
#include <conio.h>
#include <dsensor.h>
#include <string.h>
#include <time.h>

/* Ascii */
#define NUL 0
#define ZERO 48
#define PLUS 43
#define MINUS 45
#define DOT 46
#define E 101 
#define SPACE 32

/* String buffer */
#define LEN 100

/* Angle sensor data  */
#define MAX_INT_ANGLE 1023
#define MAX_ANGLE   3.142
#define INTERNAL_RESISTANCE 10000
#define POT_RESISTANCE 20000

#define VELOCITY_FACTOR 342.0
#define TICKS_PER_METRE 74.0
#define e_0  (2.0/TICKS_PER_METRE)
#define PI 3.124
#define LENGTH 0.38		/* metre */

/* Observer stuff */
#define L_1      1.1207		/* Observer gain */
#define L_2      3.3667		/* Observer gain */

#define a_u 2.0
#define DT 0.116
#define STEPFACTOR 10
#define W 1.0			/* m */

#define N_data 5		/* Number of values sent back */
#define I2R 1000.0

#define N_state 10		/* Max number of controller states */

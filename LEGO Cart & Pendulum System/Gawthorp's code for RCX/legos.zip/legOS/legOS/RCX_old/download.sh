#!/bin/sh

## Download programme or kernel
software=`basename $1 .lx`

if [ "${software}" = "kernel" ]; then
    echo Downloading legOS kernel
    ../util/firmdl3 ../boot/legOS.srec
    echo "If you get : ../util/firmdl3: unlock firmware failed, try again!"
    echo "Dont forget restart lnpd as root"
else
    echo Downloading  ${software}.lx
    ../../lnpd+liblnp/applications/dll ${software}.lx
fi
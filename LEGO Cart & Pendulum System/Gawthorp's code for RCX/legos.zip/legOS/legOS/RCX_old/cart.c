/* cart.c */
/* Lego cart main program for download to RCX */
/* Copyright (C) 2003 by Peter J. Gawthrop */

/* Under RCS version control */
/* 	$Id: cart.c,v 1.60 2003/07/23 08:56:08 peterg Exp $	 */

/* Openloop - comment out to use closed-loop */
/* #define OPEN_LOOP 1 */

#include "cart.h"		/* Main Header file */



time_t sys_time,first_time;	/* System time */
double elapsed;			/* Elapsed time since start */
double U[N_U],     U_new[N_U];
double ustar[N_U];

int i_U=0;

int new_U=0;

void initialise_sensors()
{
  /* Pendulum angle sensor */
  ds_passive(&SENSOR_2);

  /* Left sensor on */
  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  /* Calibrate left sensor to 0 */
  ds_rotation_set(&SENSOR_1,0);

  /* Right sensor on */
  ds_active(&SENSOR_3);
  ds_rotation_on(&SENSOR_3);

  /* Calibrate right sensor to 0 */
  ds_rotation_set(&SENSOR_3,0);
}

double cart_position()
{
  int position_raw;
  double position;
/*   int position_raw_left, position_raw_right; */
/*   position_raw_left = ROTATION_1; */
/*   position_raw_right = ROTATION_3; */
/*   position_raw = position_raw_left/2 + position_raw_right/2; */
  position_raw = ROTATION_1;
  position = position_raw/TICKS_PER_METRE; /* metre */
  position = 0.82*position;	/* Fiddle factor !! */
  return position;
} 

double pendulum_angle(double angle_0)
{
  double angle,resistance;
  unsigned int angle_raw;
  angle_raw = SENSOR_2/64;
  resistance = 1.0*angle_raw*INTERNAL_RESISTANCE/(MAX_INT_ANGLE-angle_raw); /* ohms */
  angle = 2*PI*(resistance/POT_RESISTANCE);	/* Radians */
  angle = 0.85*angle;		/* Fiddle factor!! */
  return angle-angle_0;
} 

double motor_velocity()
{
  int velocity_raw;
  double velocity;
  velocity_raw = (SENSOR_3/64) - 512;
  lcd_int(velocity_raw);
  velocity = velocity_raw/VELOCITY_FACTOR;
  return velocity;
} 

double sin(double theta)	/* Needs replacing with proper sin */
{
  return theta;			/* Small angle approx */
}

double abs(double x)
{
  if (x>0)
    return x;
  else
    return -x;
}

double bob_position(double angle)
{
  double position;
  position = LENGTH*sin(angle);
  return position;
} 

double drive(double u)
{

  int u_int;
  u = -u;			/* Change sign */

  /* Clip control to +- 1 */
  if (u>1) u = 1; 
  if (u<-1) u = -1; 
  
  if (u>0) {
    motor_a_dir(fwd);
    motor_c_dir(fwd);
    u_int = u*MAX_SPEED;
  }
  else
    {
      motor_a_dir(rev);
      motor_c_dir(rev);
      u_int = -u*MAX_SPEED;
    };
  
  motor_a_speed(u_int);		/* Motor speed */
  motor_c_speed(u_int);		/* Motor speed */

  u = -u;			/* Change sign */
  return u;			/* Actual control */
} 

double laguerre(double a, int i, int j)
{
/* Generates the ij coeff of the laguerre matrix*/
  if (i<j) return 0.0;
  else
    {
      if (i==j) return -a;
      else return -2*a;
    }
}

void generate_ustar(double new[N_U], double old[N_U] , double a, double dt)
{
/* Generates u* using laguerre basis fun*/
  double dxdt;
  int i,j;

  /* Laguerre part */
  for (i=0;i<N_U;i++)
    {
      dxdt = 0.0;
      for (j=0;j<N_U;j++)
	dxdt = dxdt + laguerre(a,i,j)*old[j];
      new[i] = new[i] + dxdt*dt;
    }

  for (i=0;i<N_U;i++) old[i] = new[i]; /* Save */

}

void set_ustar(double ustar[N_U], double Ustar[N_T][N_U], int i_U)
{
  int i;
  for (i=0;i<N_U;i++)
    ustar[i] = Ustar[i_U][i];
}

void initialise_u(double U[N_U])
{
  int i;
  for (i=0;i<N_U;i++)
    U[i] = 0.0;
}

/* Send data as integers via tower */
#include "putint.c"
void put_data(double elapsed, double y, double u, double v, double w)
{
  int I[N_data];

  I[0] = elapsed*100;
  I[1] = y*I2R;
  I[2] = u*I2R;
  I[3] = v*I2R;
  I[4] = w*I2R;

  putint(I);
  
};

void get_U(const unsigned char *data, unsigned char len)
/* Gets the U vector from laptop via IR */
{
  int i,I;
  char c[2];

/* Get U */
  for (i=0;i<N_U;i++)
    {
      c[0] = data[2*i];
      c[1] = data[2*i+1];
      memcpy(&I,&c,2);
      U_new[i] = I/I2R;
    };

  new_U = 1;
};

#include "controller.c"

int main(int argc, char **argv) 
{

  int i;

  double kk;
  double bob, angle, angle_0, position, position_old, velocity;
  double w = 0.0; 		/* metre */
  double y, u, u_out;
  double state[N_state];	/* Controller state */
  double t=0.0;

  sleep(1);
  lcd_clear();

  /* Initialise */
  new_U=0;
  i_U = 0;
  initialise_sensors(); 
  initialise_u(U);
  initialise_u(U_new);
  set_ustar(ustar,Ustar,i_U);

  cputs("WAIT");

  /* Setup lnp from laptop */
  lnp_integrity_set_handler(get_U);
  cputs("START");
  first_time = sys_time;

  /* Main loop */
  kk = 0;
  angle_0 = pendulum_angle(0.0);
  position_old = cart_position();
  u_out = 0;

  while(1)			/* Loop forever */
    { 
      angle = pendulum_angle(angle_0);
      bob = bob_position(angle);
      position = cart_position();
      velocity = motor_velocity();
      y = position+bob;		/* Controlled output */
      elapsed = (sys_time-first_time)/1000.0;

      /* Handle the new value of U */
      if (new_U==1)
	{
	  for (i=0;i<N_U;i++)
	    U[i] = U_new[i];	/* Change U here */
	  new_U = 0;
	  i_U = 0;
	  /* Reinitialise ustar */
	  set_ustar(ustar,Ustar,i_U);
	};

      /* Compute OL setpoint for local controller */
      w = 0;
      for (i=0;i<N_U;i++)
	{
	  w = w + U[i]*ustar[i];
	};

      lcd_int(i_U);		/* Display status */

      /* Control */
#ifdef OPEN_LOOP
      u = w;
#else
      u = controller(y,w,state);
#endif

      u_out = drive(u);		/* Clip u if required */
      put_data(elapsed,y,u_out,velocity,w); /* Send data to laptop */

      /* Increment the counter for predefined Ustar */
      if (i_U<N_T-1)		/* Don't run off the end */
	i_U++;

      t = t+DT;			/* Increment time */
      position_old = position;	/*Save y for v computation */

      /* Next Ustar vector */
 	  set_ustar(ustar,Ustar,i_U);
    }
     
  return 0;

}

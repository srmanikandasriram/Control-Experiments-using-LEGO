/* Converts a 2 byte int to a char array 
   and sends to the IR tower */

void putint(int I[N_data])
{
  unsigned char buf[2*N_data];
  short i,result,j;

  for (j=0;j<N_data;j++)
    {
      i = I[j];
      memcpy(&buf[2*j],&i,2);
    };
  
result = lnp_integrity_write(buf,2*N_data);
};

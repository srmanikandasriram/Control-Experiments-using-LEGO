/* lego.c */
/* Lego cart main program for download to RCX */
/* Copyright (C) 2003,2004 by Peter J. Gawthrop */

/* Under RCS version control */
/* 	$Id: lego.c,v 1.3 2004/03/08 16:13:20 peterg Exp $	 */

/* Use cart position -- comment out to use load position */
/* The default is to comment out the following line */
/* #define USE_CART_POSITION  */

#include "lego.h"		/* Main Header file */

time_t sys_time,first_time;	/* System time */
double elapsed;			/* Elapsed time since start */

#include "sensors.c"
#include "actuators.c"

void initialise_state(double state[N_state])
{
  int i;
  for (i=0;i<N_state;i++)
    state[i] = 0.0;
}

/* Send data as integers via tower */
#include "putint.c"
void put_data(double elapsed, double y, double u, double v, double w)
{
  int I[N_data];

  I[0] = elapsed*100;
  I[1] = y*I2R;
  I[2] = u*I2R;
  I[3] = v*I2R;
  I[4] = w*I2R;

  putint(I);
  
};

#include "controller.c"		/* User-supplied controller code */

int main(int argc, char **argv) 
{
  double kk;
  double bob, angle, angle_0, position, position_old, velocity;
  double w = 0.0; 		/* metre */
  double y, y_con, u, u_out;
  double state[N_state];	/* Controller state */
  double t=0.0;

  sleep(1);
  lcd_clear();

  /* Initialise */
  initialise_sensors(); 
  initialise_state(state);

  cputs("WAIT");

  /* Setup lnp from laptop */
  cputs("START");
  first_time = sys_time;

  /* Main loop */
  kk = 0;
  angle_0 = pendulum_angle(0.0);
  position_old = cart_position();
  u_out = 0.0;
  u = 0.0;

  while(1)			/* Loop forever */
    { 
      angle = pendulum_angle(angle_0);
      bob = bob_position(angle);
      position = cart_position();
      velocity = motor_velocity();
      y = position+bob;		/* Output */

#ifdef USE_CART_POSITION 
      y_con = position;		/* Controlled output */
#else
      y_con = y;		/* Controlled output */
#endif

      elapsed = (sys_time-first_time)/1000.0;

      /* Control */
      u = controller(y_con,u_out,w,state);

      u_out = drive(u);		/* Clip u if required */
      put_data(elapsed,y,u_out,velocity,w); /* Send data to laptop */

      t = t+DT;			/* Increment time */
      position_old = position;	/*Save y for v computation */
    }
     
  return 0;

}

/* actuators.c */
/* Actuator code for RCX */
/* Copyright (C) 2003,2004 by Peter J. Gawthrop */

double drive(double u)		/* Convert control u to motor velocities */
{

  int u_int;
  u = -u;			/* Change sign */

  /* Clip control to +- 1 */
  if (u>1) u = 1; 
  if (u<-1) u = -1; 
  
  if (u>0) {
    motor_a_dir(fwd);
    motor_c_dir(fwd);
    u_int = u*MAX_SPEED;
  }
  else
    {
      motor_a_dir(rev);
      motor_c_dir(rev);
      u_int = -u*MAX_SPEED;
    };
  
  motor_a_speed(u_int);		/* Motor speed */
  motor_c_speed(u_int);		/* Motor speed */

  u = -u;			/* Change sign */
  return u;			/* Actual control */
} 

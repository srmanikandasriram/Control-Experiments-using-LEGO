/* Angle sensor data  */
#define MAX_INT_ANGLE 1023
#define MAX_ANGLE   3.142
#define INTERNAL_RESISTANCE 10000
#define POT_RESISTANCE 20000

/* Angle sensor code */
double pendulum_angle(double angle_0)
{
  double angle,resistance;
  unsigned int angle_raw;
  angle_raw = SENSOR_2/64;
  resistance = 1.0*angle_raw*INTERNAL_RESISTANCE/
               (MAX_INT_ANGLE-angle_raw); /* ohms */
  angle = 2*PI*(resistance/POT_RESISTANCE); /* Radians */
  angle = 0.85*angle;		/* Fiddle factor!! */
  return angle-angle_0;
} 

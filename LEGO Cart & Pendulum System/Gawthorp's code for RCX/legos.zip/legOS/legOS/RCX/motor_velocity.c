/* Velocity sensor data  */
#define VELOCITY_FACTOR 342.0

/* Velocity sensor code */
double motor_velocity()
{
  int velocity_raw;
  double velocity;
  velocity_raw = (SENSOR_3/64) - 512;
  velocity = velocity_raw/VELOCITY_FACTOR;
  return velocity;
} 

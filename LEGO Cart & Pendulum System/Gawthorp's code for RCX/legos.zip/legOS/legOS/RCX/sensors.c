/* sensors.c */
/* sensor code for RCX */
/* Copyright (C) 2003,2004 by Peter J. Gawthrop */

void initialise_sensors()
{
  /* Pendulum angle sensor */
  ds_passive(&SENSOR_2);

  /* Left sensor on */
  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  /* Calibrate left sensor to 0 */
  ds_rotation_set(&SENSOR_1,0);

  /* Right sensor on */
  ds_active(&SENSOR_3);
  ds_rotation_on(&SENSOR_3);

  /* Calibrate right sensor to 0 */
  ds_rotation_set(&SENSOR_3,0);
}

#include "pendulum_angle.c"
#include "motor_velocity.c"

double sin(double theta)
{
  return theta;			/* Small angle approx */
}

double abs(double x)
{
  if (x>0)
    return x;
  else
    return -x;
}

double bob_position(double angle)
{
  double position;
  position = LENGTH*sin(angle);
  return position;
} 

double cart_position()
{
  int position_raw;
  double position;
  position_raw = ROTATION_1;
  position = position_raw/TICKS_PER_METRE; /* metre */
  position = 0.82*position;	/* Fiddle factor !! */
  return position;
} 


/* Sends integers to RCX via IR */
/* PJG Oct 02. */
 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>

#include "liblnp.h"

/* Ascii */
#define NUL 0
#define ZERO 48
#define PLUS 43
#define MINUS 45
#define DOT 46
#define E 101 
#define SPACE 32

/* Use integers - comment out to use strings */
#define MY_PORT_1  7
#define MY_PORT_2  8

#define DEST_HOST 0
#define DEST_PORT 2
#define DEST_ADDR ( DEST_HOST << 4 | DEST_PORT )
#define LEN 253

#define INTS 8

void put_int(short I[INTS], int N)
{
  char c[2],data[2*INTS];
  int ret,i,Ii;
  
   for (i=0;i<N;i++)
    {
      Ii = I[i];
      /* Copy integer to bytes */
      memcpy(&c,&Ii,2);
      /* Swap bytes */
      data[2*i]   = c[1];
      data[2*i+1] = c[0];
    }
   
   ret=lnp_integrity_write(data,2*N);

  switch (ret)
    {
    case TX_SUCCESS:
/*       printf("Sending"); */
/*       for (i=0;i<N;i++) */
/* 	printf(" %i", I[i]); */
/*       printf("\n"); */

      break;
    case TX_FAILURE:
      printf("Collision\n");
      break;
    default:
      printf("Transmit error (ret=%i)\n", ret);
      break;
    }
  };

int main(int argc, char *argv[])
{

  float x;

  short i,I[INTS],N=1;

    if ( lnp_init(0,0,0,0,0) )
    {
    	perror("lnp_init");	
    	exit(1);
    };

    N = argc-1;
    
    for (i=0;i<N;i++)
      {
	sscanf(argv[i+1],"%g", &x);
	I[i] = x*1000;
      }
    
    put_int(I,N);
    
    return 0;
}

function x = from_rcx (N)

  ## usage:  x = from_rcx (N)
  ##
  ## N number of data sets required 
  ## x data - one data set per row


  x=str2num(system(sprintf("from_rcx %i", N)));

endfunction
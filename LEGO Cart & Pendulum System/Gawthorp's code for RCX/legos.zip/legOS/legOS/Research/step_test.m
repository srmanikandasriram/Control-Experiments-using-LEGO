## Simple cart step test
U = [0.8 0 0 0];		# Control weights

N = 50;				# Number of points
dt = 0.11;			# Sample interval
t = dt*[0:2*N-1]';		# Time

collisions = to_rcx(U)		# Sent U to cart
data_1 = from_rcx(N);		# Get N data points
collisions = to_rcx(-U)		# Sent -U to cart
data_2 = from_rcx(N);		# Get N data points

data = [data_1;data_2];		# Composite data
x = data(:,1);			# Cart displacement
theta = data(:,2);		# Pendulum angle
u = data(:,3);			# Input

grid;
plot(t,x,";x;", t,theta,";theta;", t,u,";u;");

save -ascii "rcx_data.dat" data
/* Receives integers from RCX via IR */
/* PJG Sep 02. */
 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>

#include "liblnp.h"

/* Use integers - comment out to use strings */
#define USE_INTEGERS 0

#define MY_PORT_1  7
#define MY_PORT_2  8

#define DEST_HOST 0
#define DEST_PORT 2
#define DEST_ADDR ( DEST_HOST << 4 | DEST_PORT )
#define LEN 253

int data_points=0;
int N_points;

#ifdef USE_INTEGERS
void int_handler(const unsigned char* data,unsigned char length)
{
  short I,i,len,N;
  char c[2];
  int count=0;

  if (data_points++>=N_points) exit(0);


  len = (short)length;

  N = len/2;			/* Number of integers */
   for (i=0;i<N;i++)
    {
   
   /* Swap bytes */
      c[1] = data[count++];
      c[0] = data[count++];

      /* Copy bytes to integer */
      memcpy(&I,&c,2);
      fprintf(stdout," %i",I);
    }
   fprintf(stdout,"\n");
}
#else
void int_handler(const unsigned char* data,unsigned char length)
{
    char pbuf[1000];
    sprintf(pbuf,"%s\n",data);
    write(STDOUT_FILENO,pbuf,strlen(pbuf));
}
#endif

int main(int argc, char *argv[])
{

  /* Get the number of points */
  if (argc<2)
    N_points=0;
  else
    sscanf(argv[1],"%i", &N_points);

  /* Initialise lnp */
    if ( lnp_init(0,0,0,0,0) )
    {
    	perror("lnp_init");	
    	exit(1);
    };

    /* Start the handler for reception of integers   */
    lnp_integrity_set_handler (int_handler);

    while (1)
      {
	sleep(1000);
      };

    fprintf(stdout,"Done.\n");
    return 0;
}

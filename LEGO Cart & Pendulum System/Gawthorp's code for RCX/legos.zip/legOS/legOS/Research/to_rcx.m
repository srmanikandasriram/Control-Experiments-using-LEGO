function collisions = to_rcx (x)

  ## usage:  to_rcx (x)
  ##
  ## Sends x (as integers: x*1000) to rcx

  collisions = 0 ;		# Count collisions
  sent = 0;
  args="";
  for i=1:length(x)
    args = sprintf("%s %g", args, x(i));
  endfor

  command = sprintf("to_rcx%s", args);

  while !sent
    collision = system(command);

    if length(collision)>0
      collisions++;
      sent = 0;
    else
      sent = 1;
    endif
    
  endwhile

endfunction
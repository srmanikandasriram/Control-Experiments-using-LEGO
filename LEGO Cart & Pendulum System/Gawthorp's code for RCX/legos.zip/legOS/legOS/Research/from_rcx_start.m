function from_rcx_start (N)

  ## usage:  from_rcx (N)
  ##
  ## N number of data sets required 


  system(sprintf("time from_rcx %i > from_rcx.dat&", N))

endfunction